var base = require('kiosk/announcements');

Vue.component('spark-kiosk-announcements', {
    mixins: [base]
});
