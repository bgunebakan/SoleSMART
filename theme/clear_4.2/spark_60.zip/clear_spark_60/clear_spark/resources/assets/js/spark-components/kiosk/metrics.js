var base = require('kiosk/metrics');

Vue.component('spark-kiosk-metrics', {
    mixins: [base]
});
