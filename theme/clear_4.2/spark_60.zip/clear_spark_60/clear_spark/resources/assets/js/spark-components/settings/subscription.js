var base = require('settings/subscription');

Vue.component('spark-subscription', {
    mixins: [base]
});
