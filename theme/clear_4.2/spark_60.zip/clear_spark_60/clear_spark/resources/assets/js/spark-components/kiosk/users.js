var base = require('kiosk/users');

Vue.component('spark-kiosk-users', {
    mixins: [base]
});
