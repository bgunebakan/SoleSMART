var base = require('settings/teams/mailed-invitations');

Vue.component('spark-mailed-invitations', {
    mixins: [base]
});
