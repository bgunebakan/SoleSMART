var base = require('settings/invoices/invoice-list');

Vue.component('spark-invoice-list', {
    mixins: [base]
});
