var base = require('settings/profile');

Vue.component('spark-profile', {
    mixins: [base]
});
