var base = require('settings/payment-method/redeem-coupon');

Vue.component('spark-redeem-coupon', {
    mixins: [base]
});
