var base = require('settings/teams');

Vue.component('spark-teams', {
    mixins: [base]
});
