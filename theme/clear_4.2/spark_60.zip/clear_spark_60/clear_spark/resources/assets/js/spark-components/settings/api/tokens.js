var base = require('settings/api/tokens');

Vue.component('spark-tokens', {
    mixins: [base]
});
