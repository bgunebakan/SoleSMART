var base = require('settings/teams/team-membership');

Vue.component('spark-team-membership', {
    mixins: [base]
});
