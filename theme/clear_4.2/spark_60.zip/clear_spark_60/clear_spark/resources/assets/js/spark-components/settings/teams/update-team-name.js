var base = require('settings/teams/update-team-name');

Vue.component('spark-update-team-name', {
    mixins: [base]
});
