# clear_vue

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# install plugins
bower install

# compile assets
npm run dev

# compile assets with watch
npm run watch

# serve with hot reload at localhost:8080
npm run hot

# build for production with minification
npm run production

# Set the mix.setResourceRoot in webpack.mix.js if you are deploying from a sub directory of the server
mix.setResourceRoot('prefix/for/resource/locators');
```
