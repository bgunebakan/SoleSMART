<template>
    <div>
            <h5 class="font-weight-bold text-primary">Your recent views</h5>
            <div class="row mt-3">
                <div class="col-sm-2 mb-3 mb-sm-0">
                    <div class="text-center">
                        <img src="~img/ecommerce/product7.png" alt="item1" class="img-fluid mb-2">
                        <h5>T-shirt</h5>
                        <h6>$88</h6>
                        <span class="text-secondary">sale ends at 6pm</span>
                    </div>
                </div>
                <div class="col-sm-2 mb-3 mb-sm-0">
                    <div class="text-center">
                        <img src="~img/ecommerce/product6.png" alt="item2" class="img-fluid mb-2">
                        <h5>Mobile</h5>
                        <h6>$450</h6>
                        <div class="text-secondary">2 offers avilable</div>
                    </div>
                </div>
                <div class="col-sm-2 mb-3 mb-sm-0">
                    <div class="text-center">
                        <img src="~img/ecommerce/product5.png" alt="item3" class="img-fluid mb-2">
                        <h5>Camera</h5>
                        <h6>$1000</h6>
                        <div class="text-secondary">2 offers avilable</div>
                    </div>
                </div>
                <div class="col-sm-2 mb-3 mb-sm-0">
                    <div class="text-center">
                        <img src="~img/ecommerce/product8.png" alt="item4" class="img-fluid mb-2">
                        <h5>Head Phones</h5>
                        <h6>$88</h6>
                        <del class="text-secondary">
                            $99
                        </del>
                    </div>
                </div>
                <div class="col-sm-2 mb-3 mb-sm-0">
                    <div class="text-center">
                        <img src="~img/ecommerce/product7.png" alt="item5" class="img-fluid mb-2">
                        <h5>T-shirt</h5>
                        <h6>$88</h6>
                        <div class="text-secondary">2 offers avilable</div>
                    </div>
                </div>
                <div class="col-sm-2 mb-3 mb-sm-0">
                    <div class="text-center">
                        <img src="~img/ecommerce/product7.png" alt="item6" class="img-fluid mb-2">
                        <h5>T-shirt</h5>
                        <h6>$70</h6>
                        <del class="text-secondary">$88</del>
                    </div>
                </div>
            </div>
    </div>
</template>
<script>
    export default{
    name:'recent_view'
    }
</script>