webpackJsonp([41],{

/***/ 1092:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n.tablescroll, .slimScrollDiv{\n    max-height: 500px !important;\n    height: 500px !important;\n}\n", ""]);

/***/ }),

/***/ 1093:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n.search[data-v-3ba2d5ce]{\n    border: 1px solid #bdb3b3;\n}\n.contact-profile[data-v-3ba2d5ce]{\n    width:50px;\n    height: 50px;\n}\n.box-shadow[data-v-3ba2d5ce]{\n    box-shadow: 0px 0px 1px 1px #cfcfcf;\n}\n.contact-pic[data-v-3ba2d5ce]{\n    width: 50px;\n    height: 50px;\n}\n.table td[data-v-3ba2d5ce]{\n    padding: 16px;\n    vertical-align: middle;\n}\n.contacts-box .custom-control-inline[data-v-3ba2d5ce]{\n    margin-right: 0;\n}\n.custom-control-label[data-v-3ba2d5ce]::before{\n    width: 100px;\n    height: 100px;\n}\n.contact-page[data-v-3ba2d5ce]{\n    font-size: 14px;\n}\n.options a[data-v-3ba2d5ce]:hover,.options2 a[data-v-3ba2d5ce]:hover{\n    background-color: #eee;\n}\n.bg-title[data-v-3ba2d5ce]{\n    background-color: #f5f5f5;\n}\n.options .active[data-v-3ba2d5ce]{\n    background-color: #eee;\n    color: #66cc99 !important;\n    font-weight: 600;\n}\n.custom-control-inline[data-v-3ba2d5ce]{\n    margin-right: 0;\n}\n.total-contacts[data-v-3ba2d5ce]{\n    border-bottom: 1px solid #eee;\n}\n", ""]);

/***/ }),

/***/ 1751:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "contact-page"
  }, [_c('div', {
    staticClass: "container-fluid bg-white"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-12"
  }, [_c('div', {
    staticClass: "p-5 box-shadow mt-3"
  }, [_c('h4', [_vm._m(0), _vm._v(" "), _c('span', {
    staticClass: "float-right"
  }, [_c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.search),
      expression: "search"
    }],
    staticClass: "search form-control pl-2 pr-2",
    attrs: {
      "type": "search",
      "placeholder": "Search here"
    },
    domProps: {
      "value": (_vm.search)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.search = $event.target.value
      }
    }
  })])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "container-fluid bg-white mt-4"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-12"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-12 col-sm-4 col-lg-3"
  }, [_vm._m(1), _vm._v(" "), _c('button', {
    staticClass: "btn btn-primary mt-3",
    on: {
      "click": function($event) {
        _vm.modalShow = !_vm.modalShow
      }
    }
  }, [_vm._v("Add New Contact")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "hide-footer": true,
      "title": "Add your contact here"
    },
    model: {
      value: (_vm.modalShow),
      callback: function($$v) {
        _vm.modalShow = $$v
      },
      expression: "modalShow"
    }
  }, [_c('b-container', {
    attrs: {
      "fluid": ""
    }
  }, [_c('form', [_c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newname),
      expression: "newname"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "text",
      "placeholder": "Enter name"
    },
    domProps: {
      "value": (_vm.newname)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newname = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    staticClass: "btn btn-primary mt-3",
    attrs: {
      "type": "file"
    },
    on: {
      "change": _vm.onFileChange
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newnumber),
      expression: "newnumber"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "number",
      "placeholder": "Enter phone number"
    },
    domProps: {
      "value": (_vm.newnumber)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newnumber = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newemail),
      expression: "newemail"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "email",
      "placeholder": "Enter email"
    },
    domProps: {
      "value": (_vm.newemail)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newemail = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newrole),
      expression: "newrole"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "text",
      "placeholder": "Enter role"
    },
    domProps: {
      "value": (_vm.newrole)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newrole = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newlocation),
      expression: "newlocation"
    }],
    staticClass: "form-control mt-3 mb-3",
    attrs: {
      "type": "text",
      "placeholder": "Location"
    },
    domProps: {
      "value": (_vm.newlocation)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newlocation = $event.target.value
      }
    }
  }), _vm._v(" "), _c('b-btn', {
    staticClass: "float-right",
    attrs: {
      "variant": "primary"
    },
    on: {
      "click": _vm.addContact
    }
  }, [_vm._v("\n                                            Submit\n                                        ")])], 1)])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-12 col-sm-8 col-lg-9"
  }, [_c('div', {
    staticClass: "box-shadow mt-4"
  }, [_c('div', {
    staticClass: "contacts-box mb-3"
  }, [_vm._m(2), _vm._v(" "), _c('div', {
    directives: [{
      name: "slimscroll",
      rawName: "v-slimscroll"
    }],
    staticClass: "table-responsive mb-3 tablescroll"
  }, [_c('table', {
    staticClass: "table"
  }, _vm._l((_vm.allContacts), function(contact, index) {
    return _c('tr', [_c('td', [_c('b-form-checkbox')], 1), _vm._v(" "), _c('td', [_vm._v(_vm._s(contact.name))]), _vm._v(" "), _c('td', [_c('img', {
      staticClass: "contact-pic rounded-circle",
      attrs: {
        "src": contact.img,
        "alt": "profile"
      }
    })]), _vm._v(" "), _c('td', [_vm._v(_vm._s(contact.email))]), _vm._v(" "), _c('td', [_vm._v(_vm._s(contact.contact_num))]), _vm._v(" "), _c('td', [_vm._v(_vm._s(contact.role))]), _vm._v(" "), _c('td', [_vm._v(_vm._s(contact.location))]), _vm._v(" "), _c('td', [_c('span', {
      staticClass: "fa fa-edit",
      on: {
        "click": function($event) {
          _vm.editcontact(index)
        }
      }
    })]), _vm._v(" "), _c('td', [_c('span', {
      staticClass: "fa fa-trash-o",
      on: {
        "click": function($event) {
          _vm.deletecontact(index)
        }
      }
    })])])
  }))])])])])])])])])]), _vm._v(" "), _c('b-modal', {
    ref: "editcontact",
    attrs: {
      "hide-footer": "",
      "title": "Using Component Methods"
    }
  }, [_c('div', {
    staticClass: "d-block"
  }, [_c('form', [_c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editname),
      expression: "editname"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "text",
      "placeholder": "Enter name"
    },
    domProps: {
      "value": (_vm.editname)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editname = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editemail),
      expression: "editemail"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "email",
      "placeholder": "Enter email"
    },
    domProps: {
      "value": (_vm.editemail)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editemail = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editnumber),
      expression: "editnumber"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "number",
      "placeholder": "Enter number"
    },
    domProps: {
      "value": (_vm.editnumber)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editnumber = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editrole),
      expression: "editrole"
    }],
    staticClass: "form-control mt-3 mb-3",
    attrs: {
      "type": "text",
      "placeholder": "role"
    },
    domProps: {
      "value": (_vm.editrole)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editrole = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editlocation),
      expression: "editlocation"
    }],
    staticClass: "form-control mt-3 mb-3",
    attrs: {
      "type": "text",
      "placeholder": "role"
    },
    domProps: {
      "value": (_vm.editlocation)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editlocation = $event.target.value
      }
    }
  })])]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-white",
    attrs: {
      "variant": "success",
      "block": ""
    },
    on: {
      "click": function($event) {
        _vm.updateContact(_vm.contactid)
      }
    }
  }, [_vm._v("Update")]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-white",
    attrs: {
      "variant": "danger",
      "block": ""
    },
    on: {
      "click": _vm.cancel
    }
  }, [_vm._v("Cancel")])], 1), _vm._v(" "), _c('b-modal', {
    ref: "deletecontact",
    attrs: {
      "hide-footer": "",
      "title": "Using Component Methods"
    }
  }, [_c('div', {
    staticClass: "d-block text-center"
  }, [_c('h3', [_vm._v("Are you sure you want to delete modal")])]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-danger",
    attrs: {
      "variant": "outline-danger",
      "block": ""
    }
  }, [_vm._v("Yes")]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-primary",
    attrs: {
      "variant": "outline-primary",
      "block": ""
    }
  }, [_vm._v("No")])], 1)], 1)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', [_c('i', {
    staticClass: "fa fa-address-book-o"
  }), _vm._v(" Contacts\n                        ")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "box-shadow mt-4"
  }, [_c('div', {
    staticClass: "border-bottom border-secondary p-3"
  }, [_c('img', {
    staticClass: "contact-profile d-inline-block rounded-circle",
    attrs: {
      "src": __webpack_require__(307),
      "alt": "user profile"
    }
  }), _vm._v(" "), _c('p', {
    staticClass: "d-inline-block"
  }, [_vm._v("  Jon Doe")])]), _vm._v(" "), _c('div', {
    staticClass: "options border-bottom border-secondary"
  }, [_c('a', {
    staticClass: "p-3 d-block text-dark active",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("All Contacts")]), _vm._v(" "), _c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("Frequently contacted ")]), _vm._v(" "), _c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("Starred Contacts")])]), _vm._v(" "), _c('div', {
    staticClass: "options2"
  }, [_c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("Groups")]), _vm._v(" "), _c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("Friends")]), _vm._v(" "), _c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("Clients")]), _vm._v(" "), _c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("Recent Workers")]), _vm._v(" "), _c('a', {
    staticClass: "p-3 d-block text-dark",
    attrs: {
      "href": "#/contacts"
    }
  }, [_vm._v("New Group")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "total-contacts p-5 "
  }, [_c('span', [_vm._v("All Contacts(25)")])])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-3ba2d5ce", module.exports)
  }
}

/***/ }),

/***/ 1884:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1092);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("801cd956", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-3ba2d5ce\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=1!./contacts.vue", function() {
     var newContent = require("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-3ba2d5ce\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=1!./contacts.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1885:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1093);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("330eee87", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-3ba2d5ce\",\"scoped\":true,\"hasInlineConfig\":true}!../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./contacts.vue", function() {
     var newContent = require("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-3ba2d5ce\",\"scoped\":true,\"hasInlineConfig\":true}!../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./contacts.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 229:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(1885)
__webpack_require__(1884)

var Component = __webpack_require__(34)(
  /* script */
  __webpack_require__(931),
  /* template */
  __webpack_require__(1751),
  /* scopeId */
  "data-v-3ba2d5ce",
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/vue-laravel-test/resources/assets/components/pages/contacts.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] contacts.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3ba2d5ce", Component.options)
  } else {
    hotAPI.reload("data-v-3ba2d5ce", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 304:
/***/ (function(module, exports) {

module.exports = "/vue-laravel-test/public/images/avatar2.jpg?5f00b78a49d60b3c7ac514358f705a0d";

/***/ }),

/***/ 305:
/***/ (function(module, exports) {

module.exports = "/vue-laravel-test/public/images/avatar.jpg?5f00b78a49d60b3c7ac514358f705a0d";

/***/ }),

/***/ 306:
/***/ (function(module, exports) {

module.exports = "/vue-laravel-test/public/images/avatar3.jpg?5f00b78a49d60b3c7ac514358f705a0d";

/***/ }),

/***/ 307:
/***/ (function(module, exports) {

module.exports = "/vue-laravel-test/public/images/avatar1.jpg?5f00b78a49d60b3c7ac514358f705a0d";

/***/ }),

/***/ 309:
/***/ (function(module, exports) {

module.exports = "/vue-laravel-test/public/images/avatar4.jpg?5f00b78a49d60b3c7ac514358f705a0d";

/***/ }),

/***/ 591:
/***/ (function(module, exports, __webpack_require__) {

var SlimScroll = (function () {
    function $(el) {
        if (!(this instanceof $)) {
            return new $(el)
        }
        if (typeof el === 'string') {
            var r = /<(\w+)><\/\1>$/.exec(el)
            if (r) {
                el = document.createElement(r[1])
            } else {
                el = document.querySelector(el)
            }
        }
        this.el = (el && el.nodeType === 1) ? el : document.documentElement
        return this
    }

    $.prototype = {
        parent: function () {
            return $(this.el.parentNode || this.el.parentElement)
        },
        closest: function (selector) {
            if (!selector) return $(document)
            var parent = this.parent()
            while (parent.el !== $(selector).el) {
                parent = parent.parent()
            }
            return parent
        },
        is: function (obj) {
            if (this.el === obj.el) {
                return true
            }
            return false
        },
        hasClass: function (className) {
            if (this.el.className.indexOf(className) >= 0) {
                return true
            }
            return false
        },
        addClass: function (className) {
            if (!className || typeof className === 'undefined') return
            if (this.hasClass(className)) return
            var cls = this.el.className.split(' ')
            cls.push(className)
            this.el.className = cls.join(' ').trim()
            return this
        },
        css: function (styleObj) {
            if (typeof styleObj === 'string') {
                return this.el.style[styleObj].replace('px', '')
            }
            for (var key in styleObj) {
                if (typeof styleObj[key] === 'number' && parseInt(styleObj[key])) styleObj[key] = parseInt(styleObj[key]) + 'px'
                if (key === 'zIndex') styleObj[key] = parseInt(styleObj[key])
                this.el.style[key] = styleObj[key]
            }
            return this
        },
        show: function () {
            this.el.style.display = 'block'
        },
        hide: function () {
            this.el.style.display = 'none'
        },
        wrap: function (obj) {
            this.parent().el.insertBefore(obj.el, this.el)
            obj.append(this)
            return this
        },
        append: function (obj) {
            this.el.appendChild(obj.el)
            return this
        },
        scrollTop: function (y) {
            if (typeof y !== 'undefined') {
                this.el.scrollTop = parseInt(y)
                return this
            }
            return this.el.scrollTop
        },
        outerHeight: function () {
            return this.el.offsetHeight || this.el.clientHeight
        },
        hover: function (hoverIn, hoverOut) {
            this.bind('mouseenter', hoverIn)
            this.bind('mouseleave', hoverOut)
        },
        bind: function (type, fn, capture) {
            var el = this.el;

            if (window.addEventListener) {
                el.addEventListener(type, fn, capture);

                var ev = document.createEvent('HTMLEvents');
                ev.initEvent(type, capture || false, false);
                // 在元素上存储创建的事件，方便自定义触发
                if (!el['ev' + type]) {
                    el['ev' + type] = ev;
                }

            } else if (window.attachEvent) {
                el.attachEvent('on' + type, fn);
                if (isNaN(el['cu' + type])) {
                    // 自定义属性，触发事件用
                    el['cu' + type] = 0;
                }

                var fnEv = function (event) {
                    if (event.propertyName === 'cu' + type) {
                        fn.call(el);
                    }
                };

                el.attachEvent('onpropertychange', fnEv);

                // 在元素上存储绑定的propertychange事件，方便删除
                if (!el['ev' + type]) {
                    el['ev' + type] = [fnEv];
                } else {
                    el['ev' + type].push(fnEv);
                }
            }

            return this;
        },
        trigger: function (type) {
            var el = this.el;
            if (typeof type === 'string') {
                if (document.dispatchEvent) {
                    if (el['ev' + type]) {
                        el.dispatchEvent(el['ev' + type]);
                    }
                } else if (document.attachEvent) {
                    // 改变对应自定义属性，触发自定义事件
                    el['cu' + type]++;
                }
            }
            return this;
        },
        unbind: function (type, fn, capture) {
            var el = this.el;
            if (window.removeEventListener) {
                el.removeEventListener(type, fn, capture || false);
            } else if (document.attachEvent) {
                el.detachEvent('on' + type, fn);
                var arrEv = el['ev' + type];
                if (arrEv instanceof Array) {
                    for (var i = 0; i < arrEv.length; i += 1) {
                        // 删除该方法名下所有绑定的propertychange事件
                        el.detachEvent('onpropertychange', arrEv[i]);
                    }
                }
            }
            return this;
        }
    }

    $.extend = function (deep) {
        var start = 1
        if (typeof deep === 'object') {
            start = 0
        }
        var objs = Array.prototype.slice.call(arguments, start),
            newObj = {}

        for (var i = 0; i < objs.length; i++) {
            if (typeof objs !== 'object') return
            for (var key in objs[i]) {
                newObj[key] = typeof objs[i][key] === 'object' && deep === true ? $.extend(true, objs[i][key]) : objs[i][key]
            }
        }
        return newObj
    }

    $.isPlainObject = function (obj) {
        return typeof obj === 'object' && !(obj instanceof Array)
    }

    function SlimScroll(el, options) {
        var defaults = {

            // width in pixels of the visible scroll area
            width: 'auto',

            // height in pixels of the visible scroll area
            height: '250px',

            // width in pixels of the scrollbar and rail
            size: '7px',

            // scrollbar color, accepts any hex/color value
            color: '#000',

            // scrollbar position - left/right
            position: 'right',

            // distance in pixels between the side edge and the scrollbar
            distance: '1px',

            // default scroll position on load - top / bottom / $('selector')
            start: 'top',

            // sets scrollbar opacity
            opacity: 0.4,

            // enables always-on mode for the scrollbar
            alwaysVisible: false,

            // check if we should hide the scrollbar when user is hovering over
            disableFadeOut: false,

            // sets visibility of the rail
            railVisible: false,

            // sets rail color
            railColor: '#333',

            // sets rail opacity
            railOpacity: 0.2,

            // whether  we should use jQuery UI Draggable to enable bar dragging
            railDraggable: true,

            // defautlt CSS class of the slimscroll rail
            railClass: 'slimScrollRail',

            // defautlt CSS class of the slimscroll bar
            barClass: 'slimScrollBar',

            // defautlt CSS class of the slimscroll wrapper
            wrapperClass: 'slimScrollDiv',

            // check if mousewheel should scroll the window if we reach top/bottom
            allowPageScroll: false,

            // scroll amount applied to each mouse wheel step
            wheelStep: 20,

            // scroll amount applied when user is using gestures
            touchScrollStep: 200,

            // sets border radius
            borderRadius: '7px',

            // sets border radius of the rail
            railBorderRadius: '7px'
        };

        var o = $.extend(defaults, options)

        // do it for every element that matches selector
        // this.each(function () {

        var isOverPanel, isOverBar, isDragg, queueHide, touchDif,
            barHeight, percentScroll, lastScroll,
            divS = '<div></div>',
            minBarHeight = 30,
            releaseScroll = false;

        // used in event handlers and for better minification
        // var me = $(this);
        var me = $(el);

        // ensure we are not binding it again
        if (me.parent().hasClass(o.wrapperClass)) {
            // start from last bar position
            var offset = me.scrollTop();

            // find bar and rail
            bar = me.siblings('.' + o.barClass);
            rail = me.siblings('.' + o.railClass);

            getBarHeight();

            // check if we should scroll existing instance
            if ($.isPlainObject(options)) {
                // Pass height: auto to an existing slimscroll object to force a resize after contents have changed
                if ('height' in options && options.height === 'auto') {
                    me.parent().css({ height: 'auto' });
                    me.css({ height: 'auto' });
                    var height = me.parent().parent().outerHeight();
                    me.parent().css({ height: height });
                    me.css({ height: height });
                } else if ('height' in options) {
                    var h = options.height;
                    me.parent().css({ height: h });
                    me.css({ height: h });
                }

                if ('scrollTo' in options) {
                    // jump to a static point
                    offset = parseInt(o.scrollTo);
                }
                else if ('scrollBy' in options) {
                    // jump by value pixels
                    offset += parseInt(o.scrollBy);
                }
                else if ('destroy' in options) {
                    // remove slimscroll elements
                    bar.remove();
                    rail.remove();
                    me.unwrap();
                    return;
                }

                // scroll content by the given offset
                scrollContent(offset, false, true);
            }

            return;
        } else if ($.isPlainObject(options)) {
            if ('destroy' in options) {
                return;
            }
        }

        // optionally set height to the parent's height
        o.height = (o.height === 'auto') ? me.parent().outerHeight() : o.height;

        // wrap content
        var wrapper = $(divS)
            .addClass(o.wrapperClass)
            .css({
                position: 'relative',
                overflow: 'hidden',
                width: o.width,
                height: o.height
            });

        // update style for the div
        me.css({
            overflow: 'hidden',
            width: o.width,
            height: o.height
        });

        // create scrollbar rail
        var rail = $(divS)
            .addClass(o.railClass)
            .css({
                width: o.size,
                height: '100%',
                position: 'absolute',
                top: 0,
                display: (o.alwaysVisible && o.railVisible) ? 'block' : 'none',
                'border-radius': o.railBorderRadius,
                background: o.railColor,
                opacity: o.railOpacity,
                zIndex: 998
            });

        // create scrollbar
        var bar = $(divS)
            .addClass(o.barClass)
            .css({
                background: o.color,
                width: o.size,
                position: 'absolute',
                top: 0,
                opacity: o.opacity,
                display: o.alwaysVisible ? 'block' : 'none',
                'border-radius': o.borderRadius,
                BorderRadius: o.borderRadius,
                MozBorderRadius: o.borderRadius,
                WebkitBorderRadius: o.borderRadius,
                zIndex: 999
            });

        // set position
        var posCss = (o.position === 'right') ? { right: o.distance } : { left: o.distance };
        rail.css(posCss);
        bar.css(posCss);

        // wrap it
        me.wrap(wrapper);

        // append to parent div
        me.parent().append(bar);
        me.parent().append(rail);


        //all binding events callback
        var events = {
            touchStart: function (e, b) {
                if (e.originalEvent.touches.length) {
                    // record where touch started
                    touchDif = e.originalEvent.touches[0].pageY;
                }
            },
            touchMove: function (e) {
                // prevent scrolling the page if necessary
                if (!releaseScroll) {
                    e.originalEvent.preventDefault();
                }
                if (e.originalEvent.touches.length) {
                    // see how far user swiped
                    var diff = (touchDif - e.originalEvent.touches[0].pageY) / o.touchScrollStep;
                    // scroll content
                    scrollContent(diff, true);
                    touchDif = e.originalEvent.touches[0].pageY;
                }
            },
            hoverIn: function () {
                isOverPanel = true;
                showBar();
                hideBar();
            },
            hoverOut: function () {
                isOverPanel = false;
                hideBar();
            },
            barHoverIn: function () {
                isOverBar = true;
            },
            barHoverOut: function () {
                isOverBar = false;
            },
            railHoverIn: function () {
                showBar();
            },
            railHoverOut: function () {
                hideBar();
            },
            barMouseDown: function (e) {
                var $doc = $(document);
                var t = parseFloat(bar.css('top'));
                var pageY = e.pageY;
                isDragg = true;

                function mousemove(e) {
                    var currTop = t + e.pageY - pageY;
                    bar.css({ top: currTop });
                    scrollContent(0, currTop, false);// scroll content
                }

                function mouseup(e) {
                    isDragg = false; hideBar();
                    $doc.unbind('mousemove', mousemove);
                    $doc.unbind('mouseup', mouseup);
                }

                $doc.bind('mousemove', mousemove);

                $doc.bind('mouseup', mouseup);
                return false;
            },
            barSelectedStart: function (e) {
                e.stopPropagation();
                e.preventDefault();
                return false;
            }
        }

        // make it draggable and no longer dependent on the jqueryUI
        if (o.railDraggable) {
            bar.bind('mousedown', events.barMouseDown).bind('selectstart', events.barSelectedStart);
        }

        // on rail over
        rail.hover(events.railHoverIn, events.railHoverOut);

        // on bar over
        bar.hover(events.barHoverIn, events.barHoverOut);

        // show on parent mouseover
        me.hover(events.hoverIn, events.hoverOut);

        // support for mobile
        me.bind('touchstart', events.touchStart);

        me.bind('touchmove', events.touchMove);

        // set up initial height
        getBarHeight();

        // check start position
        if (o.start === 'bottom') {
            // scroll content to bottom
            bar.css({ top: me.outerHeight() - bar.outerHeight() });
            scrollContent(0, true);
        }
        else if (o.start !== 'top') {
            // assume jQuery selector
            scrollContent($(o.start).position().top, null, true);

            // make sure bar stays hidden
            if (!o.alwaysVisible) { bar.hide(); }
        }

        // attach scroll events
        attachWheel(el);

        function _onWheel(e) {
            // use mouse wheel only when mouse is over
            if (!isOverPanel) { return; }

            e = e || window.event;

            var delta = 0;
            if (e.wheelDelta) { delta = -e.wheelDelta / 120; }
            if (e.detail) { delta = e.detail / 3; }

            var target = e.target || e.srcTarget || e.srcElement;
            if ($(target).closest('.' + o.wrapperClass).is(me.parent())) {
                // scroll content
                scrollContent(delta, true);
            }

            // stop window scroll
            if (e.preventDefault && !releaseScroll) { e.preventDefault(); }
            if (!releaseScroll) { e.returnValue = false; }
        }

        function scrollContent(y, isWheel, isJump) {
            releaseScroll = false;
            var delta = y;
            var maxTop = me.outerHeight() - bar.outerHeight();

            if (isWheel) {
                // move bar with mouse wheel
                delta = parseInt(bar.css('top')) + y * parseInt(o.wheelStep) / 100 * bar.outerHeight();

                // move bar, make sure it doesn't go out
                delta = Math.min(Math.max(delta, 0), maxTop);

                // if scrolling down, make sure a fractional change to the
                // scroll position isn't rounded away when the scrollbar's CSS is set
                // this flooring of delta would happened automatically when
                // bar.css is set below, but we floor here for clarity
                delta = (y > 0) ? Math.ceil(delta) : Math.floor(delta);

                // scroll the scrollbar
                bar.css({ top: delta + 'px' });
            }

            // calculate actual scroll amount
            percentScroll = parseInt(bar.css('top')) / (me.outerHeight() - bar.outerHeight());
            // delta = percentScroll * (me[0].scrollHeight - me.outerHeight());
            delta = percentScroll * (me.el.scrollHeight - me.outerHeight());

            if (isJump) {
                delta = y;
                // var offsetTop = delta / me[0].scrollHeight * me.outerHeight();
                var offsetTop = delta / me.el.scrollHeight * me.outerHeight();
                offsetTop = Math.min(Math.max(offsetTop, 0), maxTop);
                bar.css({ top: offsetTop + 'px' });
            }

            // scroll content
            me.scrollTop(delta);

            // fire scrolling event
            me.trigger('slimscrolling', ~~delta);

            // ensure bar is visible
            showBar();

            // trigger hide when scroll is stopped
            hideBar();
        }

        function attachWheel(target) {
            if (window.addEventListener) {
                target.addEventListener('DOMMouseScroll', _onWheel, false);
                target.addEventListener('mousewheel', _onWheel, false);
            }
            else {
                document.attachEvent('onmousewheel', _onWheel)
            }
        }

        function getBarHeight() {
            // calculate scrollbar height and make sure it is not too small
            barHeight = Math.max((me.outerHeight() / me.el.scrollHeight) * me.outerHeight(), minBarHeight);
            bar.css({ height: barHeight + 'px' });

            // hide scrollbar if content is not long enough
            var display = barHeight == me.outerHeight() ? 'none' : 'block';
            bar.css({ display: display });
        }

        function showBar() {
            // recalculate bar height
            getBarHeight();
            clearTimeout(queueHide);

            // when bar reached top or bottom
            if (percentScroll == ~~percentScroll) {
                //release wheel
                releaseScroll = o.allowPageScroll;

                // publish approporiate event
                if (lastScroll != percentScroll) {
                    var msg = (~~percentScroll == 0) ? 'top' : 'bottom';
                    me.trigger('slimscroll', msg);
                }
            }
            else {
                releaseScroll = false;
            }
            lastScroll = percentScroll;

            // show only when required
            if (barHeight >= me.outerHeight()) {
                //allow window scroll
                releaseScroll = true;
                return;
            }
            // bar.stop(true, true).fadeIn('fast');
            bar.show()
            // if (o.railVisible) { rail.stop(true, true).fadeIn('fast'); }
            if (o.railVisible) { rail.show(); }
        }

        function hideBar() {
            // only hide when options allow it
            if (!o.alwaysVisible) {
                queueHide = setTimeout(function () {
                    if (!(o.disableFadeOut && isOverPanel) && !isOverBar && !isDragg) {
                        // bar.fadeOut('slow');
                        // rail.fadeOut('slow');
                        bar.hide()
                        rail.hide()
                    }
                }, 1000);
            }
        }

        // });

        function unbind() {
            // make it draggable and no longer dependent on the jqueryUI
            bar.unbind('mousedown', events.barMouseDown).unbind('selectstart', events.barSelectedStart);
            // on rail over
            rail.unbind('mouseenter', events.railHoverIn).unbind('mouseleave', events.railHoverOut);

            // on bar over
            bar.unbind('mouseenter', events.barHoverIn).unbind('mouseleave', events.barHoverOut);

            // show on parent mouseover
            me.unbind('mouseenter', events.hoverIn).unbind('mouseleave', events.hoverOut);

            // support for mobile
            me.unbind('touchstart', events.touchStart);

            me.unbind('touchmove', events.touchMove);
        }
        return {
            unbind: function () {
                bar.unbind('mousedown', events.barMouseDown)
                    .unbind('mouseenter', events.barHoverIn)
                    .unbind('mouseleave', events.barHoverOut)
                    .unbind('selectstart', events.barSelectedStart);
                rail.unbind('mouseenter', events.railHoverIn)
                    .unbind('mouseleave', events.railHoverOut);
                bar.unbind('mouseenter', events.barHoverIn)
                    .unbind('mouseleave', events.barHoverOut);
                me.unbind('mouseenter', events.hoverIn)
                    .unbind('mouseleave', events.hoverOut)
                    .unbind('touchstart', events.touchStart)
                    .unbind('touchmove', events.touchMove);
            }
        }
    }

    return SlimScroll
})()

var VueSlimScroll = {}

VueSlimScroll.install = function (Vue) {
    var ss
    Vue.directive('slimscroll', {
        inserted: function (el, binding) {
            ss = SlimScroll(el, binding.value)
        },
        unbind: function () {
            ss.unbind()
        }
    })
}


if (true) {
    module.exports = VueSlimScroll
} else if (window.Vue) {
    window.VueSlimScroll = VueSlimScroll
    Vue.use(VueSlimScroll)
}

/***/ }),

/***/ 931:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_slimscroll__ = __webpack_require__(591);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_slimscroll___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_vue_slimscroll__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



__WEBPACK_IMPORTED_MODULE_0_vue___default.a.use(__WEBPACK_IMPORTED_MODULE_1_vue_slimscroll___default.a);
/* harmony default export */ __webpack_exports__["default"] = ({
    name: 'blank',
    data: function data() {
        return {
            modalShow: false,
            newname: '',
            newemail: '',
            newnumber: '',
            newlocation: '',
            newrole: '',
            contacts: [{
                name: 'Jon',
                img: __webpack_require__(307),
                email: 'jon@gmail.com',
                contact_num: '0123456789',
                role: 'Web developer',
                location: 'Hyderabad'
            }, {
                name: 'Doe',
                img: __webpack_require__(304),
                email: 'doe@gmail.com',
                contact_num: '0123456789',
                role: 'Web developer',
                location: 'Hyderabad'
            }, {
                name: 'Addison',
                img: __webpack_require__(306),
                email: 'addison@gmail.com',
                contact_num: '0123456789',
                role: 'Web developer',
                location: 'Hyderabad'
            }, {
                name: 'Jon',
                img: __webpack_require__(309),
                email: 'jon@gmail.com',
                contact_num: '0123456789',
                role: 'Web developer',
                location: 'Hyderabad'
            }, {
                name: 'Doe',
                img: __webpack_require__(307),
                email: 'jon@gmail.com',
                contact_num: '0123456789',
                role: 'Web developer',
                location: 'Hyderabad'
            }, {
                name: 'Jon',
                img: __webpack_require__(305),
                email: 'jon@gmail.com',
                contact_num: '0123456789',
                role: 'Web developer',
                location: 'Hyderabad'
            }],
            editname: '',
            editemail: '',
            editnumber: '',
            editlocation: '',
            editrole: '',
            contactid: '',
            search: '',
            userImage: ''
        };
    },

    components: {},
    mounted: function mounted() {},
    methods: {
        addContact: function addContact() {
            this.contacts.push({
                name: this.newname,
                email: this.newemail,
                contact_num: this.newnumber,
                location: this.newlocation,
                role: this.newrole,
                img: this.userImage
            }), this.newname = '', this.newemail = '', this.newnumber = '', this.newlocation = '', this.newrole = '', this.modalShow = false;
        },
        deletecontact: function deletecontact(index) {
            //                this.$refs.deletemodal.show()
            this.contacts.splice(index, 1);
        },
        editcontact: function editcontact(index) {
            this.editname = this.contacts[index].name;
            this.editemail = this.contacts[index].email;
            this.editnumber = this.contacts[index].contact_num;
            this.editlocation = this.contacts[index].location;
            this.editrole = this.contacts[index].role;
            this.contactid = index;
            this.$refs.editcontact.show();
        },
        updateContact: function updateContact(contactid) {
            this.contacts[contactid].name = this.editname;
            this.contacts[contactid].email = this.editemail;
            this.contacts[contactid].contact_num = this.editnumber;
            this.contacts[contactid].location = this.editlocation;
            this.contacts[contactid].role = this.editrole;
            this.$refs.editcontact.hide();
            //                console.log(this.tasks[index].tasktitle);
            this.modalTask = false;
        },
        cancel: function cancel() {
            this.modalTask = false;
        },
        onFileChange: function onFileChange(e) {
            var files = e.target.files || e.dataTransfer.files;
            if (!files.length) {
                return;
            }
            this.createImage(files[0]);
        },
        createImage: function createImage(file) {
            var reader = new FileReader();
            var vm = this;

            reader.onload = function (e) {
                vm.userImage = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    },
    computed: {
        allContacts: function allContacts() {
            var self = this;
            return this.contacts.filter(function (newcontact) {
                return newcontact.name.toLowerCase().indexOf(self.search.toLowerCase()) >= 0;
            });
            //return this.customers;
        }
    }
});

/***/ })

});