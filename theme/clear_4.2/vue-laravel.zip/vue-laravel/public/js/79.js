webpackJsonp([79],{

/***/ 1778:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('b-card', {
    staticClass: "bg-primary-card",
    attrs: {
      "header": "Modals",
      "header-tag": "h4"
    }
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-lg-12"
  }, [_c('b-card', {
    staticClass: "bg-primary-card"
  }, [_c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal1",
      modifiers: {
        "modal1": true
      }
    }],
    staticClass: "mt-3 mb-3"
  }, [_vm._v("Launch demo modal")]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 mb-3",
    on: {
      "click": _vm.open_modal
    }
  }, [_vm._v("Launch modal with ref")]), _vm._v(" "), _c('b-modal', {
    ref: "modal1",
    attrs: {
      "id": "modal1",
      "title": "Modal"
    }
  }, [_c('h1', [_vm._v("modal")])]), _vm._v(" "), _c('b-modal', {
    ref: "modal21",
    attrs: {
      "id": "modal21",
      "title": "Modal"
    }
  }, [_c('h1', [_vm._v("modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-12 mt-3"
  }, [_c('b-card', {
    staticClass: "bg-info-card"
  }, [_c('h4', [_vm._v("Stop closing on backdrop click")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal2",
      modifiers: {
        "modal2": true
      }
    }]
  }, [_vm._v("Launch demo modal")]), _vm._v(" "), _c('b-modal', {
    ref: "modal2",
    attrs: {
      "no-close-on-backdrop": "",
      "id": "modal2",
      "title": "Modal"
    }
  }, [_c('h1', [_vm._v("modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal4",
      modifiers: {
        "modal4": true
      }
    }]
  }, [_vm._v("Launch small modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal4",
      "title": "Small Modal",
      "size": "sm"
    }
  }, [_c('h1', [_vm._v("modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal5",
      modifiers: {
        "modal5": true
      }
    }]
  }, [_vm._v("Launch Normal modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal5",
      "title": "Normal Modal",
      "size": "md"
    }
  }, [_c('h1', [_vm._v("modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal6",
      modifiers: {
        "modal6": true
      }
    }]
  }, [_vm._v("Launch Large modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal6",
      "title": "Large Modal",
      "size": "lg"
    }
  }, [_c('h1', [_vm._v("modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('h4', [_vm._v("Background Primary Modal ")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal8",
      modifiers: {
        "modal8": true
      }
    }]
  }, [_vm._v("Primary modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal8",
      "title": "Priamry Modal",
      "header-bg-variant": "primary",
      "header-text-variant": "light",
      "footer-bg-variant": "primary",
      "footer-text-variant": "light",
      "size": "md"
    }
  }, [_c('h1', [_vm._v(" Primary modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('h4', [_vm._v("Background Info Modal ")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal9",
      modifiers: {
        "modal9": true
      }
    }]
  }, [_vm._v("Info modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal9",
      "title": "Info Modal",
      "header-bg-variant": "info",
      "header-text-variant": "light",
      "footer-bg-variant": "info",
      "footer-text-variant": "light"
    }
  }, [_c('h1', [_vm._v(" Info modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('h4', [_vm._v("Background Warning Modal ")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal10",
      modifiers: {
        "modal10": true
      }
    }]
  }, [_vm._v("Warning modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal10",
      "title": "Warning Modal",
      "header-bg-variant": "warning",
      "header-text-variant": "light",
      "footer-bg-variant": "warning",
      "footer-text-variant": "light"
    }
  }, [_c('h1', [_vm._v(" Warning modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('h4', [_vm._v("Background Danger Modal ")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal11",
      modifiers: {
        "modal11": true
      }
    }]
  }, [_vm._v("Danger Modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal11",
      "title": "Danger Modal",
      "header-bg-variant": "danger",
      "header-text-variant": "light",
      "footer-bg-variant": "danger",
      "footer-text-variant": "light"
    }
  }, [_c('h1', [_vm._v("Danger modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('h4', [_vm._v("Background Success Modal ")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal12",
      modifiers: {
        "modal12": true
      }
    }]
  }, [_vm._v("Success Modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal12",
      "title": "Success Modal",
      "header-bg-variant": "success",
      "header-text-variant": "light",
      "footer-bg-variant": "success",
      "footer-text-variant": "light"
    }
  }, [_c('h1', [_vm._v(" Success modal")])])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "col-lg-4 mt-3"
  }, [_c('b-card', [_c('h4', [_vm._v("Background Secondary Modal ")]), _vm._v(" "), _c('b-btn', {
    directives: [{
      name: "b-modal",
      rawName: "v-b-modal.modal13",
      modifiers: {
        "modal13": true
      }
    }]
  }, [_vm._v("Secondary modal")]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "id": "modal13",
      "title": "Deafult Modal",
      "header-bg-variant": "secondary",
      "header-text-variant": "light",
      "footer-bg-variant": "secondary",
      "footer-text-variant": "light"
    }
  }, [_c('h1', [_vm._v("modal")])])], 1)], 1)])])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-5e73e866", module.exports)
  }
}

/***/ }),

/***/ 217:
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(34)(
  /* script */
  __webpack_require__(919),
  /* template */
  __webpack_require__(1778),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/vue-laravel-test/resources/assets/components/pages/advanced_modals.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] advanced_modals.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5e73e866", Component.options)
  } else {
    hotAPI.reload("data-v-5e73e866", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 919:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
    name: "modals",
    data: function data() {
        return {
            stop_close: false
        };
    },

    methods: {
        stop: function stop(e) {
            if (!this.stop_close) {
                return e.cancel();
            }
        },
        shown: function shown() {
            alert("Modal opened");
        },
        open_modal: function open_modal() {
            console.log(this.$refs);
            this.$refs.modal21.show();
        },
        hidden: function hidden() {
            alert("Modal Hidden");
        },
        success: function success() {
            alert("OK Clicked");
        },
        cancel: function cancel() {
            alert("Close Clicked");
        }
    }

});

/***/ })

});