webpackJsonp([39],{

/***/ 1194:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n.aden{-webkit-filter:hue-rotate(-20deg) contrast(.9) saturate(.85) brightness(1.2);filter:hue-rotate(-20deg) contrast(.9) saturate(.85) brightness(1.2)\n}\n.aden:after{background:linear-gradient(to right,rgba(66,10,14,.2),transparent);mix-blend-mode:darken\n}\n.inkwell{-webkit-filter:sepia(.3) contrast(1.1) brightness(1.1) grayscale(1);filter:sepia(.3) contrast(1.1) brightness(1.1) grayscale(1)\n}\n.perpetua:after{background:linear-gradient(to bottom,#005b9a,#e6c13d);mix-blend-mode:soft-light;opacity:.5\n}\n.reyes{-webkit-filter:sepia(.22) brightness(1.1) contrast(.85) saturate(.75);filter:sepia(.22) brightness(1.1) contrast(.85) saturate(.75)\n}\n.reyes:after{background:#efcdad;mix-blend-mode:soft-light;opacity:.5\n}\n.gingham{-webkit-filter:brightness(1.05) hue-rotate(-10deg);filter:brightness(1.05) hue-rotate(-10deg)\n}\n.gingham:after{background:linear-gradient(to right,rgba(66,10,14,.2),transparent);mix-blend-mode:darken\n}\n.toaster{-webkit-filter:contrast(1.5) brightness(.9);filter:contrast(1.5) brightness(.9)\n}\n.toaster:after{background:radial-gradient(circle,#804e0f,#3b003b);mix-blend-mode:screen\n}\n.walden{-webkit-filter:brightness(1.1) hue-rotate(-10deg) sepia(.3) saturate(1.6);filter:brightness(1.1) hue-rotate(-10deg) sepia(.3) saturate(1.6)\n}\n.walden:after{background:#04c;mix-blend-mode:screen;opacity:.3\n}\n.hudson{-webkit-filter:brightness(1.2) contrast(.9) saturate(1.1);filter:brightness(1.2) contrast(.9) saturate(1.1)\n}\n.hudson:after{background:radial-gradient(circle,#a6b1ff 50%,#342134);mix-blend-mode:multiply;opacity:.5\n}\n.earlybird{-webkit-filter:contrast(.9) sepia(.2);filter:contrast(.9) sepia(.2)\n}\n.earlybird:after{background:radial-gradient(circle,#d0ba8e 20%,#360309 85%,#1d0210 100%);mix-blend-mode:overlay\n}\n.mayfair{-webkit-filter:contrast(1.1) saturate(1.1);filter:contrast(1.1) saturate(1.1)\n}\n.mayfair:after{background:radial-gradient(circle at 40% 40%,rgba(255,255,255,.8),rgba(255,200,200,.6),#111 60%);mix-blend-mode:overlay;opacity:.4\n}\n.lofi{-webkit-filter:saturate(1.1) contrast(1.5);filter:saturate(1.1) contrast(1.5)\n}\n.lofi:after{background:radial-gradient(circle,transparent 70%,#222 150%);mix-blend-mode:multiply\n}\n._1977{-webkit-filter:contrast(1.1) brightness(1.1) saturate(1.3);filter:contrast(1.1) brightness(1.1) saturate(1.3)\n}\n._1977:after{background:rgba(243,106,188,.3);mix-blend-mode:screen\n}\n.brooklyn{-webkit-filter:contrast(.9) brightness(1.1);filter:contrast(.9) brightness(1.1)\n}\n.brooklyn:after{background:radial-gradient(circle,rgba(168,223,193,.4) 70%,#c4b7c8);mix-blend-mode:overlay\n}\n.xpro2{-webkit-filter:sepia(.3);filter:sepia(.3)\n}\n.xpro2:after{background:radial-gradient(circle,#E6E7E0 40%,rgba(43,42,161,.6) 110%);mix-blend-mode:color-burn\n}\n._1977:after,._1977:before,.aden:after,.aden:before,.brooklyn:after,.brooklyn:before,.earlybird:after,.earlybird:before,.gingham:after,.gingham:before,.hudson:after,.hudson:before,.inkwell:after,.inkwell:before,.lofi:after,.lofi:before,.mayfair:after,.mayfair:before,.nashville:after,.nashville:before,.perpetua:after,.perpetua:before,.reyes:after,.reyes:before,.toaster:after,.toaster:before,.walden:after,.walden:before,.xpro2:after,.xpro2:before{content:'';display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none\n}\n._1977,.aden,.brooklyn,.earlybird,.gingham,.hudson,.inkwell,.lofi,.mayfair,.nashville,.perpetua,.reyes,.toaster,.walden,.xpro2{position:relative\n}\n._1977 img,.aden img,.brooklyn img,.earlybird img,.gingham img,.hudson img,.inkwell img,.lofi img,.mayfair img,.nashville img,.perpetua img,.reyes img,.toaster img,.walden img,.xpro2 img{width:100%;z-index:1\n}\n._1977:before,.aden:before,.brooklyn:before,.earlybird:before,.gingham:before,.hudson:before,.inkwell:before,.lofi:before,.mayfair:before,.nashville:before,.perpetua:before,.reyes:before,.toaster:before,.walden:before,.xpro2:before{z-index:2\n}\n._1977:after,.aden:after,.brooklyn:after,.earlybird:after,.gingham:after,.hudson:after,.inkwell:after,.lofi:after,.mayfair:after,.nashville:after,.perpetua:after,.reyes:after,.toaster:after,.walden:after,.xpro2:after{z-index:3\n}\n.nashville{-webkit-filter:sepia(.2) contrast(1.2) brightness(1.05) saturate(1.2);filter:sepia(.2) contrast(1.2) brightness(1.05) saturate(1.2)\n}\n.nashville::after{background:rgba(0,70,150,.4);mix-blend-mode:lighten\n}\n.nashville::before{background:rgba(247,176,153,.56);mix-blend-mode:darken\n}", ""]);

/***/ }),

/***/ 1195:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n.dropify-wrapper,\n.dropify-wrapper .dropify-clear {\n    font-family : \"Open Sans\", sans-serif;\n}\n.dropify-wrapper.has-error {\n    border-color : #ff6666;\n}\n.dropify-errors-container.visible {\n    background-color : #ff6666;\n}\n.dropify-wrapper .dropify-message p.dropify-error {\n    color : #ff6666;\n}\n.p-30 {\n    padding : 30px;\n}\n.p-30 h5{\n    margin-top: 0.5rem;\n}", ""]);

/***/ }),

/***/ 1196:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n.pagination figure {\n    max-width : 100px;\n}\n.pagination > li {\n    display : inline-block;\n    margin  : 6px;\n}\n@media screen and (max-width : 342px) {\n.pagination {\n        margin-left : 2%;\n        display: -webkit-box;\n}\n}\n.pagination > li:hover, .active_filter {\n    cursor              : pointer;\n    -webkit-transform   : scale(1.1);\n    transform           : scale(1.1);\n    transition-duration : 0.3s;\n}\n.active_filter {\n    cursor              : pointer;\n    -webkit-transform   : scale(1.15);\n    transform           : scale(1.15);\n    transition-duration : 0.3s;\n    box-shadow          : 0 0 10px #555;\n    -moz-box-shadow     : 0 0 10px #555;\n    -webkit-box-shadow  : 0 0 10px #555;\n    -o-box-shadow       : 0 0 10px #555;\n}\n.dropify-render img {\n    width : 100%;\n}\n.font-ccc {\n    color : #ccc;\n}\n.dropify-wrapper,\n.dropify-wrapper .dropify-clear {\n    font-family : \"Open Sans\", sans-serif;\n}\n.dropify-wrapper.has-error {\n    border-color : #ff6666;\n}\n.dropify-errors-container.visible {\n    background-color : #ff6666;\n}\n.dropify-wrapper .dropify-message p.dropify-error {\n    color : #ff6666;\n}\n.pagination{\n    display: -webkit-inline-box;\n}\n.pagination figure{\n    margin-bottom: 0;\n}\n.lark,.toaster{\n    color:#ccc;\n}", ""]);

/***/ }),

/***/ 1810:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-lg-12"
  }, [_c('card', {
    attrs: {
      "title": "<i class='ti-image'></i> Image Filters (Aden - Hudson)"
    }
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-12"
  }, [_c('div', {
    staticClass: "col-lg-6 col-md-8 mx-auto col-xs-12 text-center"
  }, [_c('figure', {
    class: _vm.filters[_vm.isActive],
    attrs: {
      "id": "imgfigure1"
    }
  }, [_c('img', {
    staticClass: "temp_path1 img-fluid",
    attrs: {
      "src": "/static/img/gallery/full/16.jpg",
      "alt": "hudson image"
    }
  })])]), _vm._v(" "), _c('div', {
    staticClass: "col-12 text-center"
  }, [_c('ul', {
    staticClass: "pagination mx-auto"
  }, _vm._l((_vm.filters), function(filter, index) {
    return _c('li', {
      class: {
        active_filter: _vm.isActive == index
      },
      on: {
        "click": function($event) {
          _vm.isActive = index
        }
      }
    }, [_c('figure', {
      staticClass: "text-center",
      class: filter
    }, [_c('img', {
      staticClass: "temp_path1 img-fluid",
      attrs: {
        "src": "/static/img/gallery/full/16.jpg",
        "height": "75",
        "alt": "hudson image"
      }
    }), _vm._v(" "), _c('span', [_vm._v(_vm._s(filter))])])])
  }))])])])]), _vm._v(" "), _c('card', {
    attrs: {
      "title": " <i class='ti-image'></i> Image Filters (Inkwell - Perpetua)"
    }
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-12"
  }, [_c('div', {
    staticClass: "col-lg-6  col-md-8 mx-auto text-center"
  }, [_c('figure', {
    class: _vm.secondfilters[_vm.isActive],
    attrs: {
      "id": "imgfigure2"
    }
  }, [_c('img', {
    staticClass: "temp_path2 img-fluid",
    attrs: {
      "src": "/static/img/gallery/full/15.jpg",
      "alt": "inkwell image"
    }
  })])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-12 col-xs-12 text-center"
  }, [_c('ul', {
    staticClass: "pagination"
  }, _vm._l((_vm.secondfilters), function(secondfilter, index) {
    return _c('li', {
      class: {
        active_filter: _vm.isActive == index
      },
      on: {
        "click": function($event) {
          _vm.isActive = index
        }
      }
    }, [_c('figure', {
      staticClass: "text-center",
      class: secondfilter
    }, [_c('img', {
      staticClass: "temp_path2 img-fluid",
      attrs: {
        "src": "/static/img/gallery/full/15.jpg",
        "alt": "inkwell image"
      }
    }), _vm._v(" "), _c('span', [_vm._v(_vm._s(secondfilter))])])])
  }))])])])]), _vm._v(" "), _c('card', {
    attrs: {
      "title": "<i class='ti-image'></i> Image Filters (Rise - Xpro2)"
    }
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-12 col-xs-12"
  }, [_c('div', {
    staticClass: "col-lg-6  col-md-8 mx-auto text-center"
  }, [_c('figure', {
    class: _vm.thirdfilters[_vm.isActive],
    attrs: {
      "id": "imgfigure3"
    }
  }, [_c('img', {
    staticClass: "temp_path3 img-fluid",
    attrs: {
      "src": "/static/img/gallery/full/5.jpg",
      "alt": "rise image"
    }
  })])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-12 col-xs-12 text-center"
  }, [_c('ul', {
    staticClass: "pagination"
  }, _vm._l((_vm.thirdfilters), function(thirdfilter, index) {
    return _c('li', {
      class: {
        active_filter: _vm.isActive == index
      },
      on: {
        "click": function($event) {
          _vm.isActive = index
        }
      }
    }, [_c('figure', {
      staticClass: "text-center",
      class: thirdfilter
    }, [_c('img', {
      staticClass: "temp_path3 img-fluid",
      attrs: {
        "src": "/static/img/gallery/full/5.jpg",
        "height": "75",
        "alt": "rise image"
      }
    }), _vm._v(" "), _c('span', [_vm._v(_vm._s(thirdfilter))])])])
  }))])])])])], 1)])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-cc7397bc", module.exports)
  }
}

/***/ }),

/***/ 1986:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1194);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("beb89388", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../css-loader/index.js!../../../vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-cc7397bc\",\"scoped\":false,\"hasInlineConfig\":true}!./cssgram.min.css", function() {
     var newContent = require("!!../../../css-loader/index.js!../../../vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-cc7397bc\",\"scoped\":false,\"hasInlineConfig\":true}!./cssgram.min.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1987:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1195);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("70a394e6", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-cc7397bc\",\"scoped\":false,\"hasInlineConfig\":true}!./dropify.css", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-cc7397bc\",\"scoped\":false,\"hasInlineConfig\":true}!./dropify.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1988:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1196);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("47fcb2ba", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-cc7397bc\",\"scoped\":false,\"hasInlineConfig\":true}!./image_filters.css", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-cc7397bc\",\"scoped\":false,\"hasInlineConfig\":true}!./image_filters.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 251:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(1986)
__webpack_require__(1987)
__webpack_require__(1988)

var Component = __webpack_require__(34)(
  /* script */
  __webpack_require__(966),
  /* template */
  __webpack_require__(1810),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/vue-laravel-test/resources/assets/components/pages/image_filter.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] image_filter.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-cc7397bc", Component.options)
  } else {
    hotAPI.reload("data-v-cc7397bc", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 297:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    name: 'card',
    data: function data() {
        return {
            show: true,
            isActive: false
        };
    },

    methods: {
        hide: function hide() {
            this.isActive = true;
        }
    },
    mounted: function mounted() {},
    props: {
        title: {
            required: false
        }
    },
    destroy: function destroy() {}
});

/***/ }),

/***/ 298:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n.dNone{\n    display: none;\n}\n.rotate{\n    -webkit-transform:rotate(180deg);\n            transform:rotate(180deg);\n}\n", ""]);

/***/ }),

/***/ 299:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(301)

var Component = __webpack_require__(34)(
  /* script */
  __webpack_require__(297),
  /* template */
  __webpack_require__(300),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/vue-laravel-test/resources/assets/components/pages/card/card.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] card.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-25980fd9", Component.options)
  } else {
    hotAPI.reload("data-v-25980fd9", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 300:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "card",
    class: {
      dNone: _vm.isActive
    }
  }, [_c('div', {
    staticClass: "card-header"
  }, [_c('h3', {
    staticClass: "card-title",
    domProps: {
      "innerHTML": _vm._s(_vm.title)
    }
  }), _vm._v(" "), _c('span', {
    staticClass: "float-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up",
    class: {
      rotate: _vm.show
    },
    on: {
      "click": function($event) {
        _vm.show = !_vm.show
      }
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removecard",
    on: {
      "click": _vm.hide
    }
  })])]), _vm._v(" "), _c('div', {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: (_vm.show),
      expression: "show"
    }],
    staticClass: "card-body"
  }, [_vm._t("default")], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-25980fd9", module.exports)
  }
}

/***/ }),

/***/ 301:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(298);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("6867a6ca", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-25980fd9\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./card.vue", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-25980fd9\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./card.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 966:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__card_card_vue__ = __webpack_require__(299);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__card_card_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__card_card_vue__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
    name: "image_filter",
    components: {
        card: __WEBPACK_IMPORTED_MODULE_0__card_card_vue___default.a
    },
    data: function data() {
        return {
            isActive: 0,
            filters: ['brannan', 'aden', 'brooklyn', 'clarendon', 'earlybird', 'gingham', 'hudson'],
            secondfilters: ['inkwell', 'lark', 'lofi', 'mayfair', 'moon', 'nashville', 'perpetua'],
            thirdfilters: ['rise', 'slumber', 'toaster', 'valencia', 'walden', 'willow', 'xpro2']
        };
    },

    mounted: function mounted() {
        "use strict";
    },
    methods: {
        activation: function activation() {
            this.isActive = 1;
            //            console.log(this.filter);
        }
    },
    destroyed: function destroyed() {}
});

/***/ })

});