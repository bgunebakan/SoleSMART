webpackJsonp([75],{

/***/ 1119:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(11)();
exports.push([module.i, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n/* to do list */\n.todoside-menu a:hover{\n    background-color: #f5f5f5;\n}\n.todoside-menu a{\n    font-size: 15px;\n    color: #333;\n}\n.faExclamationCircle::before{\n    content: \"imp\";\n    font-size: 14px;\n    top:-8px;\n    position: relative;\n}\n.tasksearch,.tasks-list{\n    box-shadow:0px 0px 1px 1px #cfcfcf;\n}\n.todo .box-shadow{\n    box-shadow: 0px 0px 1px 1px #cfcfcf;\n}\n.tasks-table-list{\n    max-height: 80vh;\n    margin-bottom: 10px;\n}\n.todoside-menu .side-content .active{\n    background-color: #eee;\n    color: #66cc99;\n    font-weight: 600;\n}\n.table td .custom-control.custom-checkbox{\n    margin-top: 3px;\n}\n.custom-control-inline{\n    margin-right: 0;\n}\n.task-type{\n    border-bottom: 1px solid #eee;\n}\n.textDanger{\n    /*color: #ff6666;*/\n    font-weight: 600;\n}\n.textDanger::before{\n    content: '.';\n    font-size: 42px;\n    line-height: 5px;\n    font-weight: 900;\n    top: -3px;\n    left: -5px;\n    position: relative;\n    color: #ff6666;\n}\n.slimScrollDiv,.newscroll{\n    height: 500px !important;\n    max-height: 500px !important;\n}\n", ""]);

/***/ }),

/***/ 1765:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "todo mt-3"
  }, [_c('div', {
    staticClass: "todoside-menu"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-12 col-md-5 col-lg-3"
  }, [_c('div', {
    staticClass: "side-content "
  }, [_c('div', {
    staticClass: "box-shadow"
  }, [_c('h1', {
    staticClass: "p-3 mb-0"
  }, [_vm._v("Todo's")]), _vm._v(" "), _c('div', {
    staticClass: "p-3"
  }, [_c('button', {
    staticClass: "btn btn-primary btn-block",
    on: {
      "click": function($event) {
        _vm.modalTask = !_vm.modalTask
      }
    }
  }, [_vm._v("Add Task")])]), _vm._v(" "), _c('b-modal', {
    attrs: {
      "hide-footer": true,
      "title": "Add Your Task Here"
    },
    model: {
      value: (_vm.modalTask),
      callback: function($$v) {
        _vm.modalTask = $$v
      },
      expression: "modalTask"
    }
  }, [_c('b-container', {
    attrs: {
      "fluid": ""
    }
  }, [_c('form', [_c('label', {
    staticClass: "mt-2",
    attrs: {
      "for": "tasktitle"
    }
  }, [_vm._v("Task Title")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newtaskname),
      expression: "newtaskname"
    }],
    staticClass: "form-control",
    attrs: {
      "type": "text",
      "id": "tasktitle",
      "placeholder": "Enter Title"
    },
    domProps: {
      "value": (_vm.newtaskname)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newtaskname = $event.target.value
      }
    }
  }), _vm._v(" "), _c('label', {
    staticClass: "mt-2",
    attrs: {
      "for": "taskdesc"
    }
  }, [_vm._v("Task Description")]), _vm._v(" "), _c('textarea', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newtaskdesc),
      expression: "newtaskdesc"
    }],
    staticClass: "form-control",
    attrs: {
      "name": "description",
      "placeholder": "Add description here",
      "rows": "5",
      "id": "taskdesc"
    },
    domProps: {
      "value": (_vm.newtaskdesc)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newtaskdesc = $event.target.value
      }
    }
  }), _vm._v(" "), _c('label', {
    staticClass: "mt-2",
    attrs: {
      "for": "deadline"
    }
  }, [_vm._v("Deadline")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newtaskdeadline),
      expression: "newtaskdeadline"
    }],
    staticClass: "form-control",
    attrs: {
      "type": "date",
      "placeholder": "Deadline",
      "id": "deadline"
    },
    domProps: {
      "value": (_vm.newtaskdeadline)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.newtaskdeadline = $event.target.value
      }
    }
  }), _vm._v(" "), _c('label', [_c('b-form-checkbox', {
    staticClass: "mt-2",
    model: {
      value: (_vm.newimportant),
      callback: function($$v) {
        _vm.newimportant = $$v
      },
      expression: "newimportant"
    }
  }), _vm._v(" Click if this a important task")], 1), _vm._v(" "), _c('b-btn', {
    staticClass: "float-right mt-2",
    attrs: {
      "variant": "primary"
    },
    on: {
      "click": _vm.addTask
    }
  }, [_vm._v("\n                                            Submit\n                                        ")])], 1)])], 1), _vm._v(" "), _vm._m(0), _vm._v(" "), _vm._m(1), _vm._v(" "), _vm._m(2), _vm._v(" "), _vm._m(3), _vm._v(" "), _vm._m(4), _vm._v(" "), _vm._m(5)], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "col-12 col-md-7 col-lg-9"
  }, [_c('div', {
    staticClass: "tasksearch p-3"
  }, [_c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.search),
      expression: "search"
    }],
    staticClass: "form-control mt-4 mb-4",
    attrs: {
      "type": "text",
      "placeholder": "Search"
    },
    domProps: {
      "value": (_vm.search)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.search = $event.target.value
      }
    }
  })]), _vm._v(" "), _c('div', {
    staticClass: "tasks-list mt-5 mb-3"
  }, [_vm._m(6), _vm._v(" "), _c('div', {
    directives: [{
      name: "slimscroll",
      rawName: "v-slimscroll"
    }],
    staticClass: "newscroll"
  }, [_c('div', {
    staticClass: "tasks-table-list"
  }, [_c('table', {
    staticClass: "table"
  }, _vm._l((_vm.allTasks), function(task, index) {
    return _c('tr', [_c('td', [_c('b-form-checkbox')], 1), _vm._v(" "), _c('td', [_c('h5', {
      class: {
        textDanger: task.important == true
      }
    }, [_vm._v(_vm._s(task.tasktitle))]), _vm._v(" "), _c('p', [_vm._v(_vm._s(task.taskdescription))]), _vm._v(" "), _c('span', {
      staticClass: "text-danger"
    }, [_vm._v("Deadline:")]), _vm._v(" " + _vm._s(task.taskdeadline) + "\n                                            "), _c('span', {
      staticClass: "float-right mr-5"
    }, [_c('span', {
      staticClass: "text-danger"
    }, [_vm._v("Status:")]), _vm._v(" " + _vm._s(task.status))])]), _vm._v(" "), _c('td', {
      staticClass: "align-center"
    }, [_c('span', {
      staticClass: "fa fa-edit",
      on: {
        "click": function($event) {
          _vm.editModal(index)
        }
      }
    })]), _vm._v(" "), _c('td', {
      staticClass: "align-center"
    }, [_c('span', {
      staticClass: "fa fa-trash-o",
      on: {
        "click": function($event) {
          _vm.deleteModal(index)
        }
      }
    })])])
  }))])])])])])])]), _vm._v(" "), _c('b-modal', {
    ref: "editmodal",
    attrs: {
      "hide-footer": "",
      "title": "Using Component Methods"
    }
  }, [_c('div', {
    staticClass: "d-block"
  }, [_c('form', [_c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.edittitle),
      expression: "edittitle"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "text",
      "placeholder": "Enter title"
    },
    domProps: {
      "value": (_vm.edittitle)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.edittitle = $event.target.value
      }
    }
  }), _vm._v(" "), _c('textarea', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editdescription),
      expression: "editdescription"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "name": "",
      "id": "",
      "cols": "30",
      "rows": "10"
    },
    domProps: {
      "value": (_vm.editdescription)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editdescription = $event.target.value
      }
    }
  }), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.editdeadline),
      expression: "editdeadline"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "type": "email",
      "placeholder": "Enter deadline"
    },
    domProps: {
      "value": (_vm.editdeadline)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.editdeadline = $event.target.value
      }
    }
  }), _vm._v(" "), _c('select', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.newstatus),
      expression: "newstatus"
    }],
    staticClass: "form-control mt-3",
    attrs: {
      "id": "dropdown"
    },
    on: {
      "change": function($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function(o) {
          return o.selected
        }).map(function(o) {
          var val = "_value" in o ? o._value : o.value;
          return val
        });
        _vm.newstatus = $event.target.multiple ? $$selectedVal : $$selectedVal[0]
      }
    }
  }, [_c('option', {
    attrs: {
      "disabled": "",
      "value": ""
    }
  }, [_vm._v("Status")]), _vm._v(" "), _c('option', [_vm._v("Pending")]), _vm._v(" "), _c('option', [_vm._v("Completed")])])])]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-white",
    attrs: {
      "variant": "success",
      "block": ""
    },
    on: {
      "click": function($event) {
        _vm.updateModal(_vm.taskid)
      }
    }
  }, [_vm._v("Update")]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-white",
    attrs: {
      "variant": "danger",
      "block": ""
    }
  }, [_vm._v("Cancel")])], 1), _vm._v(" "), _c('b-modal', {
    ref: "deletemodal",
    attrs: {
      "hide-footer": "",
      "title": "Using Component Methods"
    }
  }, [_c('div', {
    staticClass: "d-block text-center"
  }, [_c('h3', [_vm._v("Are you sure you want to delete modal")])]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-danger",
    attrs: {
      "variant": "outline-danger",
      "block": ""
    }
  }, [_vm._v("Yes")]), _vm._v(" "), _c('b-btn', {
    staticClass: "mt-3 text-primary",
    attrs: {
      "variant": "outline-primary",
      "block": ""
    }
  }, [_vm._v("No")])], 1)], 1)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "alltasks border-bottom border-secondary d-block p-3 active",
    attrs: {
      "href": "#/task"
    }
  }, [_c('i', {
    staticClass: "fa fa-tasks",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v("  All Tasks")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "today d-block p-3",
    attrs: {
      "href": "#/task"
    }
  }, [_c('i', {
    staticClass: "fa fa-list-ol",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v("  Today's Tasks (10)")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "needaction d-block p-3",
    attrs: {
      "href": "#/task"
    }
  }, [_c('i', {
    staticClass: "fa fa-reply",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v("  Action Needed Taks (25)")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "important d-block p-3",
    attrs: {
      "href": "#/task"
    }
  }, [_c('i', {
    staticClass: "fa fa-exclamation-circle",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v("  Important Tasks (13)")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "pending d-block p-3",
    attrs: {
      "href": "#/task"
    }
  }, [_c('i', {
    staticClass: "fa fa-clock-o",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v("  Pending Taks (15)")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "deleted d-block p-3",
    attrs: {
      "href": "#/task"
    }
  }, [_c('i', {
    staticClass: "fa fa-trash-o",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v("  Deleted Tasks")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "task-type p-3"
  }, [_c('h4', [_vm._v("All Tasks")])])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-4c862238", module.exports)
  }
}

/***/ }),

/***/ 1911:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1119);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(22)("6b3b62be", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-4c862238\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./tasks.vue", function() {
     var newContent = require("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-4c862238\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./tasks.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 280:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(1911)

var Component = __webpack_require__(34)(
  /* script */
  __webpack_require__(995),
  /* template */
  __webpack_require__(1765),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/vue-laravel-test/resources/assets/components/pages/tasks.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] tasks.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-4c862238", Component.options)
  } else {
    hotAPI.reload("data-v-4c862238", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 591:
/***/ (function(module, exports, __webpack_require__) {

var SlimScroll = (function () {
    function $(el) {
        if (!(this instanceof $)) {
            return new $(el)
        }
        if (typeof el === 'string') {
            var r = /<(\w+)><\/\1>$/.exec(el)
            if (r) {
                el = document.createElement(r[1])
            } else {
                el = document.querySelector(el)
            }
        }
        this.el = (el && el.nodeType === 1) ? el : document.documentElement
        return this
    }

    $.prototype = {
        parent: function () {
            return $(this.el.parentNode || this.el.parentElement)
        },
        closest: function (selector) {
            if (!selector) return $(document)
            var parent = this.parent()
            while (parent.el !== $(selector).el) {
                parent = parent.parent()
            }
            return parent
        },
        is: function (obj) {
            if (this.el === obj.el) {
                return true
            }
            return false
        },
        hasClass: function (className) {
            if (this.el.className.indexOf(className) >= 0) {
                return true
            }
            return false
        },
        addClass: function (className) {
            if (!className || typeof className === 'undefined') return
            if (this.hasClass(className)) return
            var cls = this.el.className.split(' ')
            cls.push(className)
            this.el.className = cls.join(' ').trim()
            return this
        },
        css: function (styleObj) {
            if (typeof styleObj === 'string') {
                return this.el.style[styleObj].replace('px', '')
            }
            for (var key in styleObj) {
                if (typeof styleObj[key] === 'number' && parseInt(styleObj[key])) styleObj[key] = parseInt(styleObj[key]) + 'px'
                if (key === 'zIndex') styleObj[key] = parseInt(styleObj[key])
                this.el.style[key] = styleObj[key]
            }
            return this
        },
        show: function () {
            this.el.style.display = 'block'
        },
        hide: function () {
            this.el.style.display = 'none'
        },
        wrap: function (obj) {
            this.parent().el.insertBefore(obj.el, this.el)
            obj.append(this)
            return this
        },
        append: function (obj) {
            this.el.appendChild(obj.el)
            return this
        },
        scrollTop: function (y) {
            if (typeof y !== 'undefined') {
                this.el.scrollTop = parseInt(y)
                return this
            }
            return this.el.scrollTop
        },
        outerHeight: function () {
            return this.el.offsetHeight || this.el.clientHeight
        },
        hover: function (hoverIn, hoverOut) {
            this.bind('mouseenter', hoverIn)
            this.bind('mouseleave', hoverOut)
        },
        bind: function (type, fn, capture) {
            var el = this.el;

            if (window.addEventListener) {
                el.addEventListener(type, fn, capture);

                var ev = document.createEvent('HTMLEvents');
                ev.initEvent(type, capture || false, false);
                // 在元素上存储创建的事件，方便自定义触发
                if (!el['ev' + type]) {
                    el['ev' + type] = ev;
                }

            } else if (window.attachEvent) {
                el.attachEvent('on' + type, fn);
                if (isNaN(el['cu' + type])) {
                    // 自定义属性，触发事件用
                    el['cu' + type] = 0;
                }

                var fnEv = function (event) {
                    if (event.propertyName === 'cu' + type) {
                        fn.call(el);
                    }
                };

                el.attachEvent('onpropertychange', fnEv);

                // 在元素上存储绑定的propertychange事件，方便删除
                if (!el['ev' + type]) {
                    el['ev' + type] = [fnEv];
                } else {
                    el['ev' + type].push(fnEv);
                }
            }

            return this;
        },
        trigger: function (type) {
            var el = this.el;
            if (typeof type === 'string') {
                if (document.dispatchEvent) {
                    if (el['ev' + type]) {
                        el.dispatchEvent(el['ev' + type]);
                    }
                } else if (document.attachEvent) {
                    // 改变对应自定义属性，触发自定义事件
                    el['cu' + type]++;
                }
            }
            return this;
        },
        unbind: function (type, fn, capture) {
            var el = this.el;
            if (window.removeEventListener) {
                el.removeEventListener(type, fn, capture || false);
            } else if (document.attachEvent) {
                el.detachEvent('on' + type, fn);
                var arrEv = el['ev' + type];
                if (arrEv instanceof Array) {
                    for (var i = 0; i < arrEv.length; i += 1) {
                        // 删除该方法名下所有绑定的propertychange事件
                        el.detachEvent('onpropertychange', arrEv[i]);
                    }
                }
            }
            return this;
        }
    }

    $.extend = function (deep) {
        var start = 1
        if (typeof deep === 'object') {
            start = 0
        }
        var objs = Array.prototype.slice.call(arguments, start),
            newObj = {}

        for (var i = 0; i < objs.length; i++) {
            if (typeof objs !== 'object') return
            for (var key in objs[i]) {
                newObj[key] = typeof objs[i][key] === 'object' && deep === true ? $.extend(true, objs[i][key]) : objs[i][key]
            }
        }
        return newObj
    }

    $.isPlainObject = function (obj) {
        return typeof obj === 'object' && !(obj instanceof Array)
    }

    function SlimScroll(el, options) {
        var defaults = {

            // width in pixels of the visible scroll area
            width: 'auto',

            // height in pixels of the visible scroll area
            height: '250px',

            // width in pixels of the scrollbar and rail
            size: '7px',

            // scrollbar color, accepts any hex/color value
            color: '#000',

            // scrollbar position - left/right
            position: 'right',

            // distance in pixels between the side edge and the scrollbar
            distance: '1px',

            // default scroll position on load - top / bottom / $('selector')
            start: 'top',

            // sets scrollbar opacity
            opacity: 0.4,

            // enables always-on mode for the scrollbar
            alwaysVisible: false,

            // check if we should hide the scrollbar when user is hovering over
            disableFadeOut: false,

            // sets visibility of the rail
            railVisible: false,

            // sets rail color
            railColor: '#333',

            // sets rail opacity
            railOpacity: 0.2,

            // whether  we should use jQuery UI Draggable to enable bar dragging
            railDraggable: true,

            // defautlt CSS class of the slimscroll rail
            railClass: 'slimScrollRail',

            // defautlt CSS class of the slimscroll bar
            barClass: 'slimScrollBar',

            // defautlt CSS class of the slimscroll wrapper
            wrapperClass: 'slimScrollDiv',

            // check if mousewheel should scroll the window if we reach top/bottom
            allowPageScroll: false,

            // scroll amount applied to each mouse wheel step
            wheelStep: 20,

            // scroll amount applied when user is using gestures
            touchScrollStep: 200,

            // sets border radius
            borderRadius: '7px',

            // sets border radius of the rail
            railBorderRadius: '7px'
        };

        var o = $.extend(defaults, options)

        // do it for every element that matches selector
        // this.each(function () {

        var isOverPanel, isOverBar, isDragg, queueHide, touchDif,
            barHeight, percentScroll, lastScroll,
            divS = '<div></div>',
            minBarHeight = 30,
            releaseScroll = false;

        // used in event handlers and for better minification
        // var me = $(this);
        var me = $(el);

        // ensure we are not binding it again
        if (me.parent().hasClass(o.wrapperClass)) {
            // start from last bar position
            var offset = me.scrollTop();

            // find bar and rail
            bar = me.siblings('.' + o.barClass);
            rail = me.siblings('.' + o.railClass);

            getBarHeight();

            // check if we should scroll existing instance
            if ($.isPlainObject(options)) {
                // Pass height: auto to an existing slimscroll object to force a resize after contents have changed
                if ('height' in options && options.height === 'auto') {
                    me.parent().css({ height: 'auto' });
                    me.css({ height: 'auto' });
                    var height = me.parent().parent().outerHeight();
                    me.parent().css({ height: height });
                    me.css({ height: height });
                } else if ('height' in options) {
                    var h = options.height;
                    me.parent().css({ height: h });
                    me.css({ height: h });
                }

                if ('scrollTo' in options) {
                    // jump to a static point
                    offset = parseInt(o.scrollTo);
                }
                else if ('scrollBy' in options) {
                    // jump by value pixels
                    offset += parseInt(o.scrollBy);
                }
                else if ('destroy' in options) {
                    // remove slimscroll elements
                    bar.remove();
                    rail.remove();
                    me.unwrap();
                    return;
                }

                // scroll content by the given offset
                scrollContent(offset, false, true);
            }

            return;
        } else if ($.isPlainObject(options)) {
            if ('destroy' in options) {
                return;
            }
        }

        // optionally set height to the parent's height
        o.height = (o.height === 'auto') ? me.parent().outerHeight() : o.height;

        // wrap content
        var wrapper = $(divS)
            .addClass(o.wrapperClass)
            .css({
                position: 'relative',
                overflow: 'hidden',
                width: o.width,
                height: o.height
            });

        // update style for the div
        me.css({
            overflow: 'hidden',
            width: o.width,
            height: o.height
        });

        // create scrollbar rail
        var rail = $(divS)
            .addClass(o.railClass)
            .css({
                width: o.size,
                height: '100%',
                position: 'absolute',
                top: 0,
                display: (o.alwaysVisible && o.railVisible) ? 'block' : 'none',
                'border-radius': o.railBorderRadius,
                background: o.railColor,
                opacity: o.railOpacity,
                zIndex: 998
            });

        // create scrollbar
        var bar = $(divS)
            .addClass(o.barClass)
            .css({
                background: o.color,
                width: o.size,
                position: 'absolute',
                top: 0,
                opacity: o.opacity,
                display: o.alwaysVisible ? 'block' : 'none',
                'border-radius': o.borderRadius,
                BorderRadius: o.borderRadius,
                MozBorderRadius: o.borderRadius,
                WebkitBorderRadius: o.borderRadius,
                zIndex: 999
            });

        // set position
        var posCss = (o.position === 'right') ? { right: o.distance } : { left: o.distance };
        rail.css(posCss);
        bar.css(posCss);

        // wrap it
        me.wrap(wrapper);

        // append to parent div
        me.parent().append(bar);
        me.parent().append(rail);


        //all binding events callback
        var events = {
            touchStart: function (e, b) {
                if (e.originalEvent.touches.length) {
                    // record where touch started
                    touchDif = e.originalEvent.touches[0].pageY;
                }
            },
            touchMove: function (e) {
                // prevent scrolling the page if necessary
                if (!releaseScroll) {
                    e.originalEvent.preventDefault();
                }
                if (e.originalEvent.touches.length) {
                    // see how far user swiped
                    var diff = (touchDif - e.originalEvent.touches[0].pageY) / o.touchScrollStep;
                    // scroll content
                    scrollContent(diff, true);
                    touchDif = e.originalEvent.touches[0].pageY;
                }
            },
            hoverIn: function () {
                isOverPanel = true;
                showBar();
                hideBar();
            },
            hoverOut: function () {
                isOverPanel = false;
                hideBar();
            },
            barHoverIn: function () {
                isOverBar = true;
            },
            barHoverOut: function () {
                isOverBar = false;
            },
            railHoverIn: function () {
                showBar();
            },
            railHoverOut: function () {
                hideBar();
            },
            barMouseDown: function (e) {
                var $doc = $(document);
                var t = parseFloat(bar.css('top'));
                var pageY = e.pageY;
                isDragg = true;

                function mousemove(e) {
                    var currTop = t + e.pageY - pageY;
                    bar.css({ top: currTop });
                    scrollContent(0, currTop, false);// scroll content
                }

                function mouseup(e) {
                    isDragg = false; hideBar();
                    $doc.unbind('mousemove', mousemove);
                    $doc.unbind('mouseup', mouseup);
                }

                $doc.bind('mousemove', mousemove);

                $doc.bind('mouseup', mouseup);
                return false;
            },
            barSelectedStart: function (e) {
                e.stopPropagation();
                e.preventDefault();
                return false;
            }
        }

        // make it draggable and no longer dependent on the jqueryUI
        if (o.railDraggable) {
            bar.bind('mousedown', events.barMouseDown).bind('selectstart', events.barSelectedStart);
        }

        // on rail over
        rail.hover(events.railHoverIn, events.railHoverOut);

        // on bar over
        bar.hover(events.barHoverIn, events.barHoverOut);

        // show on parent mouseover
        me.hover(events.hoverIn, events.hoverOut);

        // support for mobile
        me.bind('touchstart', events.touchStart);

        me.bind('touchmove', events.touchMove);

        // set up initial height
        getBarHeight();

        // check start position
        if (o.start === 'bottom') {
            // scroll content to bottom
            bar.css({ top: me.outerHeight() - bar.outerHeight() });
            scrollContent(0, true);
        }
        else if (o.start !== 'top') {
            // assume jQuery selector
            scrollContent($(o.start).position().top, null, true);

            // make sure bar stays hidden
            if (!o.alwaysVisible) { bar.hide(); }
        }

        // attach scroll events
        attachWheel(el);

        function _onWheel(e) {
            // use mouse wheel only when mouse is over
            if (!isOverPanel) { return; }

            e = e || window.event;

            var delta = 0;
            if (e.wheelDelta) { delta = -e.wheelDelta / 120; }
            if (e.detail) { delta = e.detail / 3; }

            var target = e.target || e.srcTarget || e.srcElement;
            if ($(target).closest('.' + o.wrapperClass).is(me.parent())) {
                // scroll content
                scrollContent(delta, true);
            }

            // stop window scroll
            if (e.preventDefault && !releaseScroll) { e.preventDefault(); }
            if (!releaseScroll) { e.returnValue = false; }
        }

        function scrollContent(y, isWheel, isJump) {
            releaseScroll = false;
            var delta = y;
            var maxTop = me.outerHeight() - bar.outerHeight();

            if (isWheel) {
                // move bar with mouse wheel
                delta = parseInt(bar.css('top')) + y * parseInt(o.wheelStep) / 100 * bar.outerHeight();

                // move bar, make sure it doesn't go out
                delta = Math.min(Math.max(delta, 0), maxTop);

                // if scrolling down, make sure a fractional change to the
                // scroll position isn't rounded away when the scrollbar's CSS is set
                // this flooring of delta would happened automatically when
                // bar.css is set below, but we floor here for clarity
                delta = (y > 0) ? Math.ceil(delta) : Math.floor(delta);

                // scroll the scrollbar
                bar.css({ top: delta + 'px' });
            }

            // calculate actual scroll amount
            percentScroll = parseInt(bar.css('top')) / (me.outerHeight() - bar.outerHeight());
            // delta = percentScroll * (me[0].scrollHeight - me.outerHeight());
            delta = percentScroll * (me.el.scrollHeight - me.outerHeight());

            if (isJump) {
                delta = y;
                // var offsetTop = delta / me[0].scrollHeight * me.outerHeight();
                var offsetTop = delta / me.el.scrollHeight * me.outerHeight();
                offsetTop = Math.min(Math.max(offsetTop, 0), maxTop);
                bar.css({ top: offsetTop + 'px' });
            }

            // scroll content
            me.scrollTop(delta);

            // fire scrolling event
            me.trigger('slimscrolling', ~~delta);

            // ensure bar is visible
            showBar();

            // trigger hide when scroll is stopped
            hideBar();
        }

        function attachWheel(target) {
            if (window.addEventListener) {
                target.addEventListener('DOMMouseScroll', _onWheel, false);
                target.addEventListener('mousewheel', _onWheel, false);
            }
            else {
                document.attachEvent('onmousewheel', _onWheel)
            }
        }

        function getBarHeight() {
            // calculate scrollbar height and make sure it is not too small
            barHeight = Math.max((me.outerHeight() / me.el.scrollHeight) * me.outerHeight(), minBarHeight);
            bar.css({ height: barHeight + 'px' });

            // hide scrollbar if content is not long enough
            var display = barHeight == me.outerHeight() ? 'none' : 'block';
            bar.css({ display: display });
        }

        function showBar() {
            // recalculate bar height
            getBarHeight();
            clearTimeout(queueHide);

            // when bar reached top or bottom
            if (percentScroll == ~~percentScroll) {
                //release wheel
                releaseScroll = o.allowPageScroll;

                // publish approporiate event
                if (lastScroll != percentScroll) {
                    var msg = (~~percentScroll == 0) ? 'top' : 'bottom';
                    me.trigger('slimscroll', msg);
                }
            }
            else {
                releaseScroll = false;
            }
            lastScroll = percentScroll;

            // show only when required
            if (barHeight >= me.outerHeight()) {
                //allow window scroll
                releaseScroll = true;
                return;
            }
            // bar.stop(true, true).fadeIn('fast');
            bar.show()
            // if (o.railVisible) { rail.stop(true, true).fadeIn('fast'); }
            if (o.railVisible) { rail.show(); }
        }

        function hideBar() {
            // only hide when options allow it
            if (!o.alwaysVisible) {
                queueHide = setTimeout(function () {
                    if (!(o.disableFadeOut && isOverPanel) && !isOverBar && !isDragg) {
                        // bar.fadeOut('slow');
                        // rail.fadeOut('slow');
                        bar.hide()
                        rail.hide()
                    }
                }, 1000);
            }
        }

        // });

        function unbind() {
            // make it draggable and no longer dependent on the jqueryUI
            bar.unbind('mousedown', events.barMouseDown).unbind('selectstart', events.barSelectedStart);
            // on rail over
            rail.unbind('mouseenter', events.railHoverIn).unbind('mouseleave', events.railHoverOut);

            // on bar over
            bar.unbind('mouseenter', events.barHoverIn).unbind('mouseleave', events.barHoverOut);

            // show on parent mouseover
            me.unbind('mouseenter', events.hoverIn).unbind('mouseleave', events.hoverOut);

            // support for mobile
            me.unbind('touchstart', events.touchStart);

            me.unbind('touchmove', events.touchMove);
        }
        return {
            unbind: function () {
                bar.unbind('mousedown', events.barMouseDown)
                    .unbind('mouseenter', events.barHoverIn)
                    .unbind('mouseleave', events.barHoverOut)
                    .unbind('selectstart', events.barSelectedStart);
                rail.unbind('mouseenter', events.railHoverIn)
                    .unbind('mouseleave', events.railHoverOut);
                bar.unbind('mouseenter', events.barHoverIn)
                    .unbind('mouseleave', events.barHoverOut);
                me.unbind('mouseenter', events.hoverIn)
                    .unbind('mouseleave', events.hoverOut)
                    .unbind('touchstart', events.touchStart)
                    .unbind('touchmove', events.touchMove);
            }
        }
    }

    return SlimScroll
})()

var VueSlimScroll = {}

VueSlimScroll.install = function (Vue) {
    var ss
    Vue.directive('slimscroll', {
        inserted: function (el, binding) {
            ss = SlimScroll(el, binding.value)
        },
        unbind: function () {
            ss.unbind()
        }
    })
}


if (true) {
    module.exports = VueSlimScroll
} else if (window.Vue) {
    window.VueSlimScroll = VueSlimScroll
    Vue.use(VueSlimScroll)
}

/***/ }),

/***/ 995:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_slimscroll__ = __webpack_require__(591);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_slimscroll___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_vue_slimscroll__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



__WEBPACK_IMPORTED_MODULE_0_vue___default.a.use(__WEBPACK_IMPORTED_MODULE_1_vue_slimscroll___default.a);
/* harmony default export */ __webpack_exports__["default"] = ({
    name: 'blank',
    data: function data() {
        return {
            modalTask: false,
            newtaskname: '',
            newtaskdesc: '',
            newtaskdeadline: '',
            newimportant: '',
            newstatus: '',
            tasks: [{
                tasktitle: 'Task-1',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: true,
                status: 'pending'
            }, {
                tasktitle: 'Task-2',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: true,
                status: 'pending'
            }, {
                tasktitle: 'Task-3',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: false,
                status: 'completed'
            }, {
                tasktitle: 'Task-4',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: 'true',
                status: 'completed'
            }, {
                tasktitle: 'Task-5',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: 'true',
                status: 'completed'
            }, {
                tasktitle: 'Task-6',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: 'true',
                status: 'pending'
            }, {
                tasktitle: 'Task-7',
                taskdescription: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, hic quasi! Doloribus esse magni necessitatibus officia recusandae. Aliquam, aspernatur commodi, debitis harum illum odio porro quasi quia repudiandae ullam ut?',
                taskdeadline: '14/04/2018',
                important: 'true',
                status: 'pending'
            }],
            edittitle: '',
            editdescription: '',
            editdeadline: '',
            important: '',
            editnewstatus: '',
            taskid: '',
            search: '',
            options: {
                height: '1000px'
            }
        };
    },

    components: {},
    mounted: function mounted() {},
    methods: {
        addTask: function addTask() {
            this.tasks.push({
                tasktitle: this.newtaskname,
                taskdescription: this.newtaskdesc,
                taskdeadline: this.newtaskdeadline,
                important: this.newimportant,
                status: 'pending'
            }), this.newtaskname = '', this.newtaskdesc = '', this.newtaskdeadline = '', this.newimportant = false, this.newstatus = '', this.modalTask = false;
        },

        updateModal: function updateModal(taskid) {
            this.tasks[taskid].tasktitle = this.edittitle;
            this.tasks[taskid].taskdescription = this.editdescription;
            this.tasks[taskid].taskdeadline = this.editdeadline;
            this.tasks[taskid].status = this.newstatus;
            //                console.log(this.editnewstatus);
            this.$refs.editmodal.hide();
            //                console.log(this.tasks[index].tasktitle);
            this.modalTask = false;
        },
        editModal: function editModal(index) {
            this.edittitle = this.tasks[index].tasktitle;
            this.editdescription = this.tasks[index].taskdescription;
            this.editdeadline = this.tasks[index].taskdeadline;
            this.editnewstatus = this.tasks[index].status;
            this.taskid = index;
            this.$refs.editmodal.show();
        },
        deleteModal: function deleteModal(index) {
            this.tasks.splice(index, 1);
        }
    },
    computed: {
        allTasks: function allTasks() {
            var self = this;
            return this.tasks.filter(function (newtask) {
                return newtask.tasktitle.toLowerCase().indexOf(self.search.toLowerCase()) >= 0;
            });
            //return this.customers;
        }
    }
});

/***/ })

});