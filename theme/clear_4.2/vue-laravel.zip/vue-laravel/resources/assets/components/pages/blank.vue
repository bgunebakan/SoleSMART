<template>
    <div>
        
    </div>
</template>
<script>
    
    export default {
        name:'blank',
        data(){
            return{
                
            }
        },
        components:{
           
        },
        mounted:function(){


        },
        methods: {
            
        }
    }
</script>
<style scoped>
    


</style>
