<template>
    <div>
        <!--main content-->
        <div class="row">
            <div class="col-md-12">
                <card title="<i class='fa fa-fw ti-settings'></i> 2D Transforms Flat Buttons">
                    <div class="flatbuttons">
                        <div class="text-left">
                            <h5>Radiused Buttons</h5>
                            <ul class="mb-5">
                                <li>
                                    <button type="button" class="btn btn-default btn-lg hvr-buzz butn">Buzz</button>
                                </li>
                                <li>
                                    <button class="button button-rounded button-primary-flat hvr-hang">Hang
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-rounded button-action-flat hvr-sink">Sink
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-rounded button-highlight-flat hvr-pop">Pop
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-rounded button-caution-flat hvr-float">Float
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-rounded button-royal-flat hvr-rotate">Rotate
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="text-left btn-rounded">
                            <h5>Rounded Buttons</h5>
                            <ul class="mb-5">
                                <li>
                                    <button class="button button-default button-pill button-flat hvr-grow">
                                        Grow Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-pill button-primary-flat hvr-shrink">
                                        ShrinkButton
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-pill button-action-flat hvr-pulse">
                                        Pulse Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-pill button-highlight-flat hvr-pulse-grow">
                                        Pulse-grow
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-pill button-caution-flat hvr-pulse-shrink">
                                        Pulse-shrink
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-pill button-royal-flat hvr-push">
                                        Push Button
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="text-left">
                            <h5>Rectangle Box</h5>
                            <ul class="mb-5">
                                <li>
                                    <button class="button button-default button-flat hvr-wobble-skew">Button</button>
                                </li>
                                <li>
                                    <button class="button button-primary-flat hvr-wobble-bottom">Button</button>
                                </li>
                                <li>
                                    <button class="button button-action-flat hvr-wobble-to-top-right">Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-highlight-flat hvr-wobble-vertical">Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-caution-flat hvr-wobble-horizontal">Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-royal-flat hvr-skew-backward">Button</button>
                                </li>
                            </ul>
                        </div>
                        <div class="text-left">
                            <h5>Cirlce Buttons</h5>
                            <ul class="mb-5">
                                <li>
                                    <button class="button button-default button-circle button-flat hvr-wobble-top">Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-circle button-primary-flat hvr-skew">Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-circle button-action-flat hvr-wobble-to-top-right">
                                        Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-circle button-highlight-flat hvr-pulse-grow">
                                        Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-circle button-caution-flat hvr-grow">Button
                                    </button>
                                </li>
                                <li>
                                    <button class="button button-circle button-royal-flat hvr-buzz-out">Button
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </card>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <card title="<i class='ti-bell'></i> Shadow and Glow Transitions Buttons">
                    <div class="flatbuttons_small">
                        <ul>
                            <li>
                                <button class="button button-default button-glow button-rounded button-flat hvr-float-shadow">
                                    Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-glow button-rounded button-primary-flat hvr-float-shadow">
                                    Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-glow button-rounded button-action-flat hvr-float-shadow">
                                    Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-glow button-rounded button-highlight-flat hvr-float-shadow">
                                    Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-glow button-rounded button-caution-flat hvr-float-shadow">
                                    Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-glow button-rounded button-royal-flat hvr-float-shadow">
                                    Button
                                </button>
                            </li>
                        </ul>
                    </div>
                </card>
            </div>
            <div class="col-md-6">
                    <card title="<i class='ti-rocket'></i> Quick Shortcuts">
                        <div class="quick_shortcuts">
                            <div class="row">
                                <div class="col-6 col-md-6">
                                    <button class="btn btn-danger  btn-responsive" role="button">
                                        <span class="fa fa-list-alt"></span>
                                        <br/> Apps
                                    </button>
                                    <button class="btn btn-warning  btn-responsive" role="button">
                                        <span class="fa fa-bookmark"></span>
                                        <br/> Bookmarks
                                    </button>
                                    <button class="btn btn-primary  btn-responsive" role="button">
                                        <span class="fa fa-signal"></span>
                                        <br/> Reports
                                    </button>
                                    <button class="btn btn-primary  btn-responsive" role="button">
                                        <span class="fa fa-comment"></span>
                                        <br/> Comments
                                    </button>
                                </div>
                                <div class="col-6 col-md-6">
                                    <button class="btn btn-success  btn-responsive" role="button">
                                        <span class="fa fa-user"></span>
                                        <br/> Users
                                    </button>
                                    <button class="btn btn-info  btn-responsive" role="button">
                                        <span class="fa fa-file"></span>
                                        <br/> Notes
                                    </button>
                                    <button class="btn btn-primary  btn-responsive" role="button">
                                        <span class="fa fa-picture-o"></span>
                                        <br/> Photos
                                    </button>
                                    <button class="btn btn-primary  btn-responsive" role="button">
                                        <span class="fa fa-tag"></span>
                                        <br/> Tags
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-md-12 mt-2">
                                <button class="btn btn-success btn-lg btn-block" role="button">
                                    <span class="fa fa-globe"></span> Website
                                </button>
                            </div>
                        </div>
                    </card>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <card title="<i class='ti-rocket'></i> 3-D Buttons">
                    <div class="flatbuttons">
                        <ul>
                            <li>
                                <button class="button button-default button-3d">Button</button>
                            </li>
                            <li>
                                <button class="button button-3d button-primary button-rounded btn_3d">Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-3d button-action button-pill btn_3d">Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-3d button-highlight button-circle btn_3d">Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-3d button-caution icon-btn btn_3d">
                                    <i class="fa ti-instagram"></i> Button
                                </button>
                            </li>
                            <li>
                                <button class="button button-3d button-royal btn_3d">Button</button>
                            </li>
                        </ul>
                    </div>
                </card>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <card title="<i class='ti-arrow-circle-up'></i> Spinner Buttons">
                    <div class="pad_left">
                        <div class="text-left">
                            <div class="row ">
                                <div class="col-lg-12">
                                    <h5>Buttons</h5>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-xl-2 col-sm-4">
                                    <button class="ladda-button btn btn-primary button_normal"
                                            data-style="expand-left">Expand-left
                                    </button>
                                </div>
                                <div class="col-md-3 col-xl-2 col-sm-4">
                                    <button class="ladda-button btn btn-primary button_normal"
                                            data-style="expand-right">Expand-right
                                    </button>
                                </div>
                                <div class="col-md-3 col-xl-2 col-sm-4">
                                    <button class="ladda-button btn btn-primary button_normal"
                                            data-style="expand-up">Expand-up
                                    </button>
                                </div>
                                <div class="col-md-3 col-xl-2 col-sm-4">
                                    <button class="ladda-button btn btn-primary button_normal"
                                            data-style="slide-down">Slide-down
                                    </button>
                                </div>
                                <div class="col-md-3 col-xl-2 col-sm-4">
                                    <button class="ladda-button btn btn-primary button_normal" data-style="contract">Contract</button>
                                </div>
                                <div class="col-md-3 col-xl-2 col-sm-4">
                                    <button class="ladda-button btn btn-primary button_normal"
                                            data-style="zoom-in">Zoom-in
                                    </button>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-lg-12">
                                    <h5>Icon Buttons</h5>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2 col-sm-4">
                                    <button class="ladda-button btn btn-info button_normal text-white"
                                            data-style="slide-left"><i class="fa ti-arrow-circle-left"
                                                                       aria-hidden="true"></i> Slide-left
                                    </button>
                                </div>
                                <div class="col-md-2 col-sm-4">
                                    <button class="ladda-button btn btn-info button_normal text-white"
                                            data-style="slide-right">Slide-right <i
                                            class="fa ti-arrow-circle-right" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <div class="col-md-2 col-sm-4">
                                    <button class="ladda-button btn btn-info button_normal text-white"
                                            data-style="slide-up">Slide-up <i class="fa ti-arrow-circle-up"
                                                                              aria-hidden="true"></i>
                                    </button>
                                </div>
                                <div class="col-md-2 col-sm-4">
                                    <button class="ladda-button btn btn-info button_normal text-white"
                                            data-style="contract"><i class="fa ti-filter" aria-hidden="true"></i>
                                        Contract
                                    </button>
                                </div>
                                <div class="col-md-2 col-sm-4">
                                    <button class="ladda-button btn btn-info button_normal text-white"
                                            data-style="zoom-out"><i class="fa ti-zoom-out"
                                                                     aria-hidden="true"></i> Zoom-out
                                    </button>
                                </div>
                            </div>
                            <!--===========================  progress button spinners  ===========================-->
                            <div class="row">

                                <div class="col-md-12 col-sm-6">
                                    <div class="row text-left">
                                        <div class="col-lg-12">
                                            <h5>Button Sizes</h5>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <button class="ladda-button btn btn-warning btn-lg button_normal text-white"
                                                    data-style="expand-right">Large
                                            </button>
                                        </div>
                                        <div class="col-md-4">
                                            <button class="ladda-button btn btn-warning  button_normal text-white"
                                                    data-style="expand-right">Small
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-6">
                                    <div class="row text-left">
                                        <div class="col-lg-12">
                                            <h5>Progress Button Spinners</h5>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5">
                                            <button class="ladda-button btn btn-success button_progress text-white"
                                                    data-style="expand-right">Expand-right
                                            </button>
                                        </div>
                                        <div class="col-md-5">
                                            <button class="ladda-button btn btn-success button_progress text-white"
                                                    data-style="contract">contract
                                            </button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </card>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <card title="<i class='fa fa-fw ti-settings'></i> Buttons">
                    <div class="flatbuttons">
                        <div class="row">
                            <!-- Example Icon Button -->
                            <div class="col-md-12">
                                <h5 class="example-title">Icon Button & Dropdown</h5>
                                <div class="example example-buttons">
                                    <button type="button" class="btn btn-icon btn-default m-r-50 mb-2"><i
                                            class="icon fa fa-fw ti-location-pin" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-icon btn-primary m-r-50 mb-2"><i
                                            class="icon fa fa-fw ti-layout-grid3" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-icon btn-success m-r-50 mb-2"><i
                                            class="icon fa fa-fw ti-bell" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-icon btn-info m-r-50 mb-2"><i
                                            class="icon fa fa-fw ti-calendar" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-icon btn-warning btn-round m-r-50 mb-2"><i
                                            class="icon fa fa-fw ti-time" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-icon btn-danger btn-round m-r-50 mb-2"><i
                                            class="icon fa fa-fw ti-flag-alt-2" aria-hidden="true"></i>
                                    </button>
                                    <div class="btn-group drop_btn" role="group">
                                        <b-dropdown right split variant="primary" class="pt-0">
                                            <template slot="button-content"><i class="ti-calendar more"></i>
                                            </template>
                                            <b-dropdown-item>Dropdown</b-dropdown-item>
                                            <b-dropdown-item>Dropdown</b-dropdown-item>
                                        </b-dropdown>
                                    </div>
                                </div>
                            </div>
                            <!-- End Example Icon Button -->
                        </div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <!-- Example Icon Dropdown -->
                                <div class="example-wrap">
                                    <h5 class="example-title">Button Animation</h5>
                                    <div class="btn-group display_media" role="group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <button type="button"
                                                        class="btn btn-animate btn-animate-side btn-success m-r-50">
                                                    <span><i class="icon fa fa-fw ti-import" aria-hidden="true"></i>Side Animation</span>
                                                </button>
                                            </div>
                                            <div class="col-sm-6">
                                                <button type="button"
                                                        class="btn btn-animate btn-animate-vertical btn-lg btn-success m-r-50">
                                                        <span><i class="icon fa fa-fw ti-import"
                                                                 aria-hidden="true"></i>Vertical
                                                                      Animation</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Example Icon Dropdown -->
                            </div>
                        </div>
                    </div>
                </card>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <card title="<i class='ti-layout-column3'></i> Group buttons">
                    <div>
                        <div class="col-md-12 text-center">
                            <div class="ui-group-buttons">
                                <a href="#/buttons" class="btn btn-success" role="button">
                                    <span class="fa fa-thumbs-up"></span>
                                </a>
                                <div class="or"></div>
                                <a href="#/buttons" class="btn btn-danger" role="button">
                                    <span class="fa fa-thumbs-down"></span>
                                </a>
                            </div>
                            <div class="ui-group-buttons">
                                <a href="#/buttons" class="btn btn-success" role="button">
                                    <span class="fa fa-floppy-o"></span>
                                </a>
                                <div class="or"></div>
                                <a href="#/buttons" class="btn btn-danger" role="button">
                                    <span class="fa fa-trash"></span>
                                </a>
                            </div>
                            <br/>
                            <br/>
                            <div class="ui-group-buttons">
                                <a href="#/buttons" class="btn btn-success" role="button">
                                    <span class="fa fa-check"></span> Sign Up
                                </a>
                                <div class="or"></div>
                                <a href="#/buttons" class="btn btn-default" role="button">
                                    <span class="fa fa-remove"></span> Reset
                                </a>
                            </div>
                            <br/>
                            <br/>
                            <div class="ui-group-buttons">
                                <button type="button" class="btn btn-primary btn-lg">Large</button>
                                <div class="or or-lg"></div>
                                <button type="button" class="btn btn-success btn-lg">Large</button>
                            </div>
                            <br/>
                            <br/>
                            <div class="ui-group-buttons">
                                <button type="button" class="btn btn-primary">Default</button>
                                <div class="or"></div>
                                <button type="button" class="btn btn-success">Success</button>
                            </div>
                            <br/>
                            <br/>
                            <div class="ui-group-buttons">
                                <button type="button" class="btn btn-primary ">
                                    Small
                                </button>
                                <div class="or or-sm"></div>
                                <button type="button" class="btn btn-success ">
                                    Small
                                </button>
                            </div>
                            <br/>
                        </div>
                    </div>
                </card>
            </div>
            <div class="col-md-6">
                <card class="labled-buttons" title="<i class='ti-save'></i> Buttons With Labels">
                    <div class="col-lg-12 col-md-12 col-12 col-sm-12">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-success">
                                                <span class="btn-label">
                                                <i class="fa fa-check"></i>
                                            </span> Success
                                </button>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-danger">
                                                <span class="btn-label">
                                                <i class="fa fa-remove"></i>
                                            </span> Cancel
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-warning">
                                                <span class="btn-label">
                                                <i class="fa fa-bookmark"></i>
                                            </span> Bookmark
                                </button>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-primary">
                                                <span class="btn-label">
                                                <i class="fa fa-camera"></i>
                                            </span> Camera
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-default text-dark">
                                                <span class="btn-label">
                                                <i class="fa fa-chevron-left"></i>
                                            </span> Left
                                </button>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-default text-dark">
                                    Right <span class="btn-label label-right">
                                                <i class="fa fa-chevron-right"></i>
                                            </span>
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-success">
                                                <span class="btn-label">
                                                        <i class="fa fa-fw ti-thumb-up"></i>
                                                    </span> Up
                                </button>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-warning">
                                                <span class="btn-label">
                                                <i class="fa fa-fw ti-thumb-down"></i>
                                            </span> Down
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-info">
                                                <span class="btn-label">
                                                <i class="fa fa-refresh"></i>
                                            </span> Refresh
                                </button>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <button type="button" class="btn btn-labeled btn-primary">
                                                <span class="btn-label">
                                                <i class="fa fa-trash"></i>
                                            </span> Trash
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <a class="btn btn-warning btn-labeled text-white" role="button">
                                                <span class="btn-label butn_clr">
                                                <i class="fa fa-info-circle"></i>
                                            </span> Info Web
                                </a>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <a class="btn btn-success btn-labeled text-white" role="button">
                                                <span class="btn-label">
                                                <i class="fa fa-globe"></i>
                                            </span> Web
                                </a>
                            </div>
                        </div>
                    </div>
                </card>
            </div>
        </div>
        <!--main content ends-->
    </div>
</template>
<script>
    import card from "./card/card.vue";
    import buttons from "Buttons/js/buttons.js"
    var Ladda = require('ladda');
    export default {
        name: "buttons",
        components:{
            card
        },
        mounted: function() {
            "use strict";
                //INITIALIZE PAGE
                // Bind normal buttons
                Ladda.bind('.button_normal', {
                    timeout: 3000
                });

                // Bind progress buttons and simulate loading progress
                Ladda.bind('.button_progress', {
                    callback: function(instance) {
                        var progress = 0;
                        var interval = setInterval(function() {
                            progress = Math.min(progress + Math.random() * 0.1, 1);
                            instance.setProgress(progress);

                            if (progress === 1) {
                                instance.stop();
                                clearInterval(interval);
                            }
                        }, 200);
                    }
                });
        },
        destroyed: function() {

        }
    }
</script>
<style src="hover.css/css/hover-min.css"></style>

<style lang="sass">
    @import "../../assets/sass/buttons/buttons.scss"
</style>
<style src="ladda-bootstrap/dist/ladda-themeless.min.css"></style>
<style src="../../assets/css/advbuttons.css"></style>
<style>
    .ladda-spinner div {
    top: 5px !important;
    left: 5px !important;
}
.quick_shortcuts .btn-responsive,.quick_shortcuts .btn-block {
    margin-top: 0.5rem;
}
.ui-group-buttons .btn-default{
    background-color: #ccc;
}
.example-buttons .btn{
    padding: 0.6rem 1.25rem;
    font-size: 1.1rem;
}
.hvr-buzz{
    padding-right: 40px;
    padding-left: 40px;
    color: #666;
}
    .ui-group-buttons .or-lg:before{
        width:1.5em;
        height:1.5em;
        top: 7px;
        left:85%;
    }
    .ui-group-buttons .or-lg:after{
        height:2.75rem !important;
    }
    .or-sm:after{
        border-bottom: 2rem solid #5a5a5a !important;
    }
    .pad_left .ladda-button{
        margin-bottom: 10px;
    }
    .flatbuttons  .hvr-buzz:hover{
        color: #333;
    }
    .button:active,.btn:active,.btn-success:focus,.ui-group-buttons .btn-default,.ui-group-buttons a{
        color:#fff !important;
    }
    .button-default:active,.hvr-buzz:active,.btn-default.text-dark:active{
        color: #333 !important;
    }
    .btn-animate-vertical{
        padding: 8px 12px;
    }
    .ui-group-buttons .or:after{
        height:2.75em;
    }
    .ui-group-buttons .or.or-sm{
        height: 1.4em;
    }
    @media(max-width: 1024px){
        .boxed .pad_left{
            padding-left: 0;
        }
        .boxed .pad_left .text-left .col-md-2,.boxed .pad_left .text-left .col-sm-4{
            padding-left: 13px;
            padding-right: 13px;
            margin-right: 10px;
        }
        .labled_buttons .col-md-6{
            margin-right: 10px;
        }
    }
    .btn-labeled{
        margin-bottom: 10px;
    }
    .flatbuttons ul{
        padding-top: 0;
    }
    .flatbuttons button{
        margin-top: 0;
    }
</style>